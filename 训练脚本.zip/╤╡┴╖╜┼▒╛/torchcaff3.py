
import torch
import torchvision
from pytorch2caffe import pytorch2caffe
import model
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
def SaveDemo():
    from torchvision.models import resnet
 
    name = 'EDSR'

#    Model = model.EDSR()
    Model = torch.load('./caffe/model.pth')
    Model.eval()
    Model = Model.to(device)
    dummy_input = torch.ones([1, 3, 180, 320])
    dummy_input = dummy_input.to(device)
    pytorch2caffe.trans_net(Model, dummy_input, name)
    pytorch2caffe.save_prototxt('{}.prototxt'.format(name))
    pytorch2caffe.save_caffemodel('{}.caffemodel'.format(name))

 
if __name__ == '__main__':
    SaveDemo()