import model
import dataset
import torch.optim as optim
import torch
from torch.utils.data import DataLoader
from torch.autograd import Variable
import torch.nn as nn
import time
import os
from math import log10
from PIL import Image
import numpy as np
import dealdataset
from torchvision.transforms import Compose, CenterCrop, ToTensor, Resize
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
#device = torch.device('cpu')
upscale_factor = 4
batch_size = 16
nEpoch = 3000


    #1准备数据集
if not os.path.exists('D:\\EDSR\\DIV2K\\mybin\\DIV2K_train_HR\\0001.png.npy'):
    dealdataset.deal_dataset("D:\\EDSR\\DIV2K\\DIV2K_train_HR","D:\\EDSR\\DIV2K\\mybin\\DIV2K_train_HR")
if not os.path.exists('D:\\EDSR\\DIV2K\\mybin\\DIV2K_test_LR_bicubic\\x4\\0901x4.png.npy'):
    dealdataset.deal_dataset("D:\\EDSR\\DIV2K\\DIV2K_test_LR_bicubic\\x4","D:\\EDSR\\DIV2K\\mybin\\DIV2K_test_LR_bicubic\\x4")
if not os.path.exists('D:\\EDSR\\DIV2K\\mybin\\DIV2K_train_LR_bicubic\\x4\\0001x4.png.npy'):
    dealdataset.deal_dataset("D:\\EDSR\\DIV2K\\DIV2K_train_LR_bicubic\\x4","D:\\EDSR\\DIV2K\\mybin\\DIV2K_train_LR_bicubic\\x4")
train_dataset = dataset.get_dataset('D:\EDSR\DIV2K\\mybin',upscale_factor,mode =  "train")
test_dataset = np.load('D:\\EDSR\\DIV2K\\mybin\\DIV2K_train_LR_unknown\\x4\\0001x4.png.npy')
test_dataset = ToTensor()(test_dataset)
test_dataset = Variable(torch.unsqueeze(test_dataset, dim=0).float(), requires_grad=True)
train_dataset_loader = DataLoader(dataset = train_dataset,batch_size = batch_size,shuffle = True)
    #2构建模型
print("making model")

if os.path.exists("./model/model.pth"):
    Model = torch.load("./model/model.pth")
    Model.eval()
    Model.to(device)
else :
    Model = model.EDSR()
    Model.to(device)
    #构建优化器
optimizer = optim.Adam(Model.parameters(),lr=0.0001)
loss_fn = nn.L1Loss()
scheduler =optim.lr_scheduler.ExponentialLR(optimizer, gamma=0.98)
#if os.path.exists("./model/optimizer_state_dict.pt"):
#    optimizer.load_state_dict(torch.load("./model/optimizer_state_dict.pt"))



def train(epoch):
    epoch_loss = 0
    avg_psnr = 0;
    read_time = 0
    start_read = time.time()
    start = time.time()
    for iteration, batch  in enumerate(train_dataset_loader,1):
        end_read = time.time()
        read_time += end_read - start_read
        input,target = Variable(batch[0]),Variable(batch[1])
        input = input.to(device)
        target = target.to(device)
        optimizer.zero_grad()
        loss = loss_fn(Model(input),target)
        psnr = 10 *log10(1/(2*(loss.item()**2)))
        avg_psnr += psnr
        epoch_loss += loss.item()
        loss.backward()
        optimizer.step()
        if iteration%25 ==0:
            end = time.time()
            print(epoch,"%.5f"%loss.item(),end - start,read_time)
            read_time = 0
            start = time.time()
            torch.save(Model,"./model/model.pth")#保存模型
            torch.save(Model.state_dict(),"./model/model_state_dict.pt")#保存模型
            torch.save(optimizer.state_dict(),"./model/optimizer_state_dict.pt")#保存优化器
        start_read = time.time()
    print("===>avg. PSNR: {:.4f}dB".format(avg_psnr/len(train_dataset_loader)))

def test():
    avg_psnr = 0
    start = time.time()
    if(1):
        with torch.no_grad():
            input = test_dataset
            input = input.to(device)
            output = Model(input)
           
           #output = output.transpose([0,1,3,2])
            if 1:
                output = output.cpu()
                output_img = output[0].numpy()
                output_img = (output_img) *255
                output_img = output_img.clip(0,255)
                ar = Image.fromarray(output_img[0]).convert('L')
                ag = Image.fromarray(output_img[1]).convert('L')
                ab = Image.fromarray(output_img[2]).convert('L')
                out = Image.merge("RGB",[ar,ag,ab])
                out.save("./test/output.jpg")
                input = input.cpu()
                input = input[0].numpy()
                input = (input) *255
                input = input.clip(0,255)
                ar = Image.fromarray(input[0]).convert('L')
                ag = Image.fromarray(input[1]).convert('L')
                ab = Image.fromarray(input[2]).convert('L')
                out = Image.merge("RGB",[ar,ag,ab])
                out.save("./test/input.jpg")



def main():
    print("train begin")
    for epoch in range(1,nEpoch+1):
        train(epoch)
        if(epoch %5)==0:
           test()
        if(epoch%300)==0:
            scheduler.step()
            print('lr={:.6f}'.format(scheduler.get_lr()[0]))
    print("train end")
if __name__=="__main__":
    main()
    test()



