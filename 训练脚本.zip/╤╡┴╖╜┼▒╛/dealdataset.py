import time
from PIL import Image
from os import makedirs, remove,listdir
import os
import numpy as np
from os.path import exists, join, basename
path = "D:\\EDSR\\DIV2K\\DIV2K_train_HR"
def load_img(filepath):
    img = Image.open(filepath).convert('RGB')
    #
    return img

def deal_dataset(image_dir,reslut_path):
    image_filename = [join(image_dir,x) for x in listdir(image_dir) ]
    img_lenth = len(image_filename)
    image_filename[0].replace(image_dir,'').replace('\\','')
    start = time.time()
    for i in range(img_lenth):
        img = load_img(image_filename[i])
        name =os.path.join( reslut_path,image_filename[i].replace(image_dir,'').replace('\\',''))
        name = name + ".npy"
        img =  np.array(img)
        np.save(name,img)
        print("dealing dataset",name)
    print(time.time() - start)
    






