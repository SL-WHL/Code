
from torch.utils.data import DataLoader 
import os
import torch
import torch.optim as optim
import torch.nn.functional as F
from torchvision.transforms import ToTensor,Compose,Normalize
import numpy as np
import torch.nn as nn




class ResBlock(nn.Module):
    def __init__(self, channels=64):
        super(ResBlock, self).__init__()
        self.conv1 = nn.Conv2d(channels, channels, 3, 1, 1)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = nn.Conv2d(channels, channels, 3, 1, 1)

    def forward(self, x):
        identity = x
        conv1 = self.conv1(x)
        relu = self.relu(conv1)
        conv2 = self.conv2(relu)

        output = conv2 + identity
        return output

class EDSR(nn.Module):
    def __init__(self,
                 num_blocks=16,
                 num_features=8,
                 block=ResBlock()):
        super(EDSR, self).__init__()
        self.head = nn.Conv2d(3, num_features, 3, 1, 1)
        body = [
            ResBlock(num_features) for _ in range(num_blocks)
        ]
        body.append(nn.Conv2d(num_features, num_features, 3, 1, 1))
        self.body = nn.Sequential(*body)
        self.tail = nn.Sequential(
            nn.Conv2d(num_features, num_features*4, 3, 1, 1),
            nn.ConvTranspose2d(in_channels=num_features*4, out_channels= num_features,  kernel_size=2, stride=2, padding=0,output_padding=0, bias= False),
            nn.Conv2d(num_features, num_features*4, 3, 1, 1),
            nn.ConvTranspose2d(in_channels=num_features*4, out_channels= num_features,  kernel_size=2, stride=2, padding=0,output_padding=0, bias= False),
            nn.Conv2d(num_features, 3, 3, 1, 1)
        )

    def forward(self, x):
        x = self.head(x)
        res = self.body(x)
        res += x
        x = self.tail(res)
        return x


