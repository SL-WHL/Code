
from os.path import exists, join, basename
from os import makedirs, remove,listdir
import torch.optim as optim
#from six.moves import urllib
import tarfile
from torchvision.transforms import Compose, CenterCrop, ToTensor, Resize
from torchvision.datasets import ImageFolder
from torch.utils.data import DataLoader
from torch.utils import data
from PIL import Image
import copy
import numpy as np
import time
import os
import random
# train = torch.utils.DataLoader(dataset, batch_size=64, suffle=True)


path = "D:\EDSR\DIV2K\mybin"
batch_size = 16

def is_image_file(filename):
    return any(filename.endswith(extension) for externsion in [".png",".jpg",".jpeg"])
read_time =0;

def load_img(filepath):
    start =  time.time()
    img = np.load(filepath)
    img = Image.fromarray(img,"RGB")
    end = time.time()
    return img

def crop_array(array,X,Y,width,hight):#绝对坐标
    return array[X:X+hight,Y:Y+width]

size = 0
X = 0
Y = 0
count_numimg=0
img_input = {}
img_target ={}
def load_img(filepath):
    return np.load(filepath)
def load_img_target(filepath,idx):
    global size,X,Y,count_numimg,img_target
    if count_numimg==0:
        img = np.load(filepath[idx%4])
        img_target = crop_array(img,X*4,Y*4,size *4 ,size*4)
        img = img_target
    elif count_numimg == 1:
        img =np.fliplr(img_target)
    elif count_numimg == 2:
        img =np.flipud(img_target)
    elif count_numimg == 3:
        img =np.rot90(img_target)
        img =np.rot90(img)
    return img
def load_img_input(filepath,idx):
    global size,X,Y,count_numimg,img_input
    if count_numimg==0:
        img = np.load(filepath[idx%4])
        hight = img.shape[0]
        width = img.shape[1]
        if hight > width:
            hight = width
        else:
            width = hight
        size  =  random.randint(50,200)
        size = 48
        X = random.randint(0,hight - size)
        Y = random.randint(0,hight - size)
        img_input = crop_array(img,X,Y,size,size)
        img = img_input
    elif count_numimg == 1:
        img =np.fliplr(img_input)
    elif count_numimg == 2:
        img =np.flipud(img_input)
    elif count_numimg == 3:
        img =np.rot90(img_input)
        img =np.rot90(img)
    
    return img

class DatasetFromFolder(data.Dataset):
    def __init__(self,image_dir,input_transform =None,target_transform=None):
        super(DatasetFromFolder,self).__init__()
        super(DatasetFromFolder,self).__init__()
        path1 = os.path.join(image_dir,"DIV2K_train_HR")
        path2 = os.path.join(image_dir,"DIV2K_train_LR_bicubic\\x4")
        self.image_filename_target = [join(path1,x) for x in listdir(path1) ] 
        self.image_filename_input = [join(path2,x) for x in listdir(path2) ] 

        self.input_transform = input_transform
        self.target_transform = target_transform
    def __getitem__(self,index):
        global count_numimg
        input = load_img_input(self.image_filename_input,index)
        target = load_img_target(self.image_filename_target,index)
        #target = copy.copy(input)
        #target = Image.fromarray(target)
        #input = Image.fromarray(input)
        count_numimg +=1
        if count_numimg==4:
            count_numimg = 0    
        if self.input_transform:
#            input = Image.fromarray(input)
            input = input.copy()
#            input.show()
            input = self.input_transform(input)
        if self.target_transform:
            target = target.copy()
#            target = Image.fromarray(target)
#            target.show()
            target = self.target_transform(target)
        return input,target
    def __len__(self):
        return 4*len(self.image_filename_input)

def calculate_valid_crop_size(crop_size, upscale_factor):
    return crop_size - (crop_size % upscale_factor)

def input_transform(crop_size, upscale_factor):
    return Compose([

        ToTensor()
    ])
 
 
def target_transform(crop_size):
    return Compose([

        ToTensor()
    ])


def get_dataset(root, upscale_factor,mode):
    if mode == 'train':
        path = join(root,"DIV2K_train_HR")
        crop_size = calculate_valid_crop_size(400,upscale_factor)
        return DatasetFromFolder(root,input_transform=input_transform(crop_size, upscale_factor),
                             target_transform=target_transform(crop_size))
    elif mode =='test':
        path = join(root,"x4")
        crop_size = calculate_valid_crop_size(400,upscale_factor)
        return DatasetFromFolder(path,input_transform=input_transform(crop_size, upscale_factor),
                             target_transform=target_transform(crop_size))





