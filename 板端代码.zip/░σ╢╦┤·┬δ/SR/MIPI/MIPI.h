#pragma once
#include "sample_comm.h"
#include "hi_mipi_tx.h"

HI_S32 SAMPLE_VO_CONFIG_MIPI(HI_S32* mipiFD);
HI_S32 SAMPLE_COMM_VO_StartVO_MIPI(SAMPLE_VO_CONFIG_S* pstVoConfig);
HI_S32 SAMPLE_VO_DISABLE_MIPITx(HI_S32 fd);