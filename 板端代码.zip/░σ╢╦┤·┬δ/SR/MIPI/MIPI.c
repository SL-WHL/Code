
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ioctl.h>

#include "sample_comm.h"
#include "hi_mipi_tx.h"

HI_S32 SAMPLE_OPEN_MIPITx_FD(HI_VOID)
{
    HI_S32 fd;

    fd = open("/dev/hi_mipi_tx", O_RDWR);
    if (fd < 0) {
        printf("open hi_mipi_tx dev failed\n");
    }
    return fd;
}

HI_VOID SAMPLE_CLOSE_MIPITx_FD(HI_S32 fd)
{
    close(fd);
    return;
}

HI_VOID SAMPLE_GetMipiTxConfig(combo_dev_cfg_t* pstMipiTxConfig)
{
    /* USER NEED SET MIPI DEV CONFIG */
    pstMipiTxConfig->devno = 0;
    pstMipiTxConfig->lane_id[0] = 0;
    pstMipiTxConfig->lane_id[1] = 1;
    pstMipiTxConfig->lane_id[2] = -1;
    pstMipiTxConfig->lane_id[3] = -1;
    pstMipiTxConfig->output_mode = OUTPUT_MODE_DSI_VIDEO;
    pstMipiTxConfig->output_format = OUT_FORMAT_RGB_24_BIT;
    pstMipiTxConfig->video_mode = BURST_MODE;
    pstMipiTxConfig->sync_info.vid_pkt_size = 480;
    pstMipiTxConfig->sync_info.vid_hsa_pixels = 10;
    pstMipiTxConfig->sync_info.vid_hbp_pixels = 50;
    pstMipiTxConfig->sync_info.vid_hline_pixels = 590;
    pstMipiTxConfig->sync_info.vid_vsa_lines = 4;
    pstMipiTxConfig->sync_info.vid_vbp_lines = 20;
    pstMipiTxConfig->sync_info.vid_vfp_lines = 20;
    pstMipiTxConfig->sync_info.vid_active_lines = 800;
    pstMipiTxConfig->sync_info.edpi_cmd_size = 0;
    pstMipiTxConfig->phy_data_rate = 359;
    pstMipiTxConfig->pixel_clk = 29878;

    return;
}

HI_S32 SAMPLE_SetMipiTxConfig(HI_S32 fd, combo_dev_cfg_t* pstMipiTxConfig)
{
    HI_S32 s32Ret;
    s32Ret = ioctl(fd, HI_MIPI_TX_SET_DEV_CFG, pstMipiTxConfig);
    if (s32Ret != HI_SUCCESS) {
        printf("MIPI_TX SET_DEV_CONFIG failed\n");
        SAMPLE_CLOSE_MIPITx_FD(fd);
        return s32Ret;
    }
    return s32Ret;
}

HI_S32 SAMPLE_SET_MIPITx_Dev_ATTR(HI_S32 fd)
{
    HI_S32 s32Ret;
    combo_dev_cfg_t stMipiTxConfig;

    /* USER SET MIPI DEV CONFIG */
    SAMPLE_GetMipiTxConfig(&stMipiTxConfig);

    /* USER SET MIPI DEV CONFIG */
    s32Ret = SAMPLE_SetMipiTxConfig(fd, &stMipiTxConfig);

    return s32Ret;
}

HI_S32 SAMPLE_USER_INIT_MIPITx(HI_S32 fd, cmd_info_t* pcmd_info)
{
    HI_S32 s32Ret;

    s32Ret = ioctl(fd, HI_MIPI_TX_SET_CMD, pcmd_info);
    if (s32Ret != HI_SUCCESS) {
        printf("MIPI_TX SET CMD failed\n");
        SAMPLE_CLOSE_MIPITx_FD(fd);
        return s32Ret;
    }

    return HI_SUCCESS;
}
static unsigned char m_buf[50];
HI_S32 SAMPLE_VO_INIT_MIPITx_Screen(HI_S32 fd)
{
    HI_S32 s32Ret;
    cmd_info_t cmd_info;
    memset(m_buf, 0, 50);
    m_buf[0] = 0xFF; m_buf[1] = 0x77; m_buf[2] = 0x01; m_buf[3] = 0x00; m_buf[4] = 0x00; m_buf[5] = 0x13;
    cmd_info.devno = 0;
    cmd_info.cmd_size = 6;
    cmd_info.data_type = 0x29;
    cmd_info.cmd = m_buf;
    s32Ret = SAMPLE_USER_INIT_MIPITx(fd, &cmd_info);
    if (s32Ret != HI_SUCCESS) {
        return s32Ret;
    }
    usleep(1000);

    //memset(m_buf, 0, 50);
    //m_buf[0] = 0xEF; m_buf[1] = 0x08;
    cmd_info.devno = 0;
    cmd_info.cmd_size = 0x08ef;
    cmd_info.data_type = 0x23;
    cmd_info.cmd = NULL;
    s32Ret = SAMPLE_USER_INIT_MIPITx(fd, &cmd_info);
    if (s32Ret != HI_SUCCESS) {
        return s32Ret;
    }
    usleep(1000);

    memset(m_buf, 0, 50);
    m_buf[0] = 0xFF; m_buf[1] = 0x77; m_buf[2] = 0x01; m_buf[3] = 0x00; m_buf[4] = 0x00; m_buf[5] = 0x10;
    cmd_info.devno = 0;
    cmd_info.cmd_size = 6;
    cmd_info.data_type = 0x29;
    cmd_info.cmd = m_buf;
    s32Ret = SAMPLE_USER_INIT_MIPITx(fd, &cmd_info);
    if (s32Ret != HI_SUCCESS) {
        return s32Ret;
    }
    usleep(1000);

    memset(m_buf, 0, 50);
    m_buf[0] = 0xC0; m_buf[1] = 0x63; m_buf[2] = 0x00;
    cmd_info.devno = 0;
    cmd_info.cmd_size = 3;
    cmd_info.data_type = 0x29;
    cmd_info.cmd = m_buf;
    s32Ret = SAMPLE_USER_INIT_MIPITx(fd, &cmd_info);
    if (s32Ret != HI_SUCCESS) {
        return s32Ret;
    }
    usleep(1000);

    memset(m_buf, 0, 50);
    m_buf[0] = 0xC1; m_buf[1] = 0x10; m_buf[2] = 0x02;
    cmd_info.devno = 0;
    cmd_info.cmd_size = 3;
    cmd_info.data_type = 0x29;
    cmd_info.cmd = m_buf;
    s32Ret = SAMPLE_USER_INIT_MIPITx(fd, &cmd_info);
    if (s32Ret != HI_SUCCESS) {
        return s32Ret;
    }
    usleep(1000);

    memset(m_buf, 0, 50);
    m_buf[0] = 0xC2; m_buf[1] = 0x01; m_buf[2] = 0x08;
    cmd_info.devno = 0;
    cmd_info.cmd_size = 3;
    cmd_info.data_type = 0x29;
    cmd_info.cmd = m_buf;
    s32Ret = SAMPLE_USER_INIT_MIPITx(fd, &cmd_info);
    if (s32Ret != HI_SUCCESS) {
        return s32Ret;
    }
    usleep(1000);

    cmd_info.devno = 0;
    cmd_info.cmd_size = 0x18CC;
    cmd_info.data_type = 0x23;
    cmd_info.cmd = NULL;
    s32Ret = SAMPLE_USER_INIT_MIPITx(fd, &cmd_info);
    if (s32Ret != HI_SUCCESS) {
        return s32Ret;
    }
    usleep(1000);

    memset(m_buf, 0, 50);
    m_buf[0] = 0xB0; m_buf[1] = 0x40; m_buf[2] = 0xC9; m_buf[3] = 0x8F; m_buf[4] = 0x0D; m_buf[5] = 0x11; m_buf[6] = 0x07; m_buf[7] = 0x02;
    m_buf[8] = 0x09; m_buf[9] = 0x09; m_buf[10] = 0x1F; m_buf[11] = 0x04; m_buf[12] = 0x50; m_buf[13] = 0x0F; m_buf[14] = 0xE4; m_buf[15] = 0x29; m_buf[16] = 0xDF;
    cmd_info.devno = 0;
    cmd_info.cmd_size = 17;
    cmd_info.data_type = 0x29;
    cmd_info.cmd = m_buf;
    s32Ret = SAMPLE_USER_INIT_MIPITx(fd, &cmd_info);
    if (s32Ret != HI_SUCCESS) {
        return s32Ret;
    }
    usleep(1000);

    memset(m_buf, 0, 50);
    m_buf[0] = 0xB1; m_buf[1] = 0x40; m_buf[2] = 0xCB; m_buf[3] = 0xD3; m_buf[4] = 0x11; m_buf[5] = 0x8F; m_buf[6] = 0x04; m_buf[7] = 0x00;
    m_buf[8] = 0x08; m_buf[9] = 0x07; m_buf[10] = 0x1C; m_buf[11] = 0x06; m_buf[12] = 0x53; m_buf[13] = 0x12; m_buf[14] = 0x63; m_buf[15] = 0xEB; m_buf[16] = 0xDF;
    cmd_info.devno = 0;
    cmd_info.cmd_size = 17;
    cmd_info.data_type = 0x29;
    cmd_info.cmd = m_buf;
    s32Ret = SAMPLE_USER_INIT_MIPITx(fd, &cmd_info);
    if (s32Ret != HI_SUCCESS) {
        return s32Ret;
    }
    usleep(1000);

    memset(m_buf, 0, 50);
    m_buf[0] = 0xFF; m_buf[1] = 0x77; m_buf[2] = 0x01; m_buf[3] = 0x00; m_buf[4] = 0x00; m_buf[5] = 0x11;
    cmd_info.devno = 0;
    cmd_info.cmd_size = 6;
    cmd_info.data_type = 0x29;
    cmd_info.cmd = m_buf;
    s32Ret = SAMPLE_USER_INIT_MIPITx(fd, &cmd_info);
    if (s32Ret != HI_SUCCESS) {
        return s32Ret;
    }
    usleep(1000);

    cmd_info.devno = 0;
    cmd_info.cmd_size = 0x65b0;
    cmd_info.data_type = 0x23;
    cmd_info.cmd = NULL;
    s32Ret = SAMPLE_USER_INIT_MIPITx(fd, &cmd_info);
    if (s32Ret != HI_SUCCESS) {
        return s32Ret;
    }
    usleep(1000);

    cmd_info.devno = 0;
    cmd_info.cmd_size = 0x34b1;
    cmd_info.data_type = 0x23;
    cmd_info.cmd = NULL;
    s32Ret = SAMPLE_USER_INIT_MIPITx(fd, &cmd_info);
    if (s32Ret != HI_SUCCESS) {
        return s32Ret;
    }
    usleep(1000);

    cmd_info.devno = 0;
    cmd_info.cmd_size = 0x87b2;
    cmd_info.data_type = 0x23;
    cmd_info.cmd = NULL;
    s32Ret = SAMPLE_USER_INIT_MIPITx(fd, &cmd_info);
    if (s32Ret != HI_SUCCESS) {
        return s32Ret;
    }
    usleep(1000);

    cmd_info.devno = 0;
    cmd_info.cmd_size = 0x80b3;
    cmd_info.data_type = 0x23;
    cmd_info.cmd = NULL;
    s32Ret = SAMPLE_USER_INIT_MIPITx(fd, &cmd_info);
    if (s32Ret != HI_SUCCESS) {
        return s32Ret;
    }
    usleep(1000);

    cmd_info.devno = 0;
    cmd_info.cmd_size = 0x49b5;
    cmd_info.data_type = 0x23;
    cmd_info.cmd = NULL;
    s32Ret = SAMPLE_USER_INIT_MIPITx(fd, &cmd_info);
    if (s32Ret != HI_SUCCESS) {
        return s32Ret;
    }
    usleep(1000);

    cmd_info.devno = 0;
    cmd_info.cmd_size = 0x85b7;
    cmd_info.data_type = 0x23;
    cmd_info.cmd = NULL;
    s32Ret = SAMPLE_USER_INIT_MIPITx(fd, &cmd_info);
    if (s32Ret != HI_SUCCESS) {
        return s32Ret;
    }
    usleep(1000);

    cmd_info.devno = 0;
    cmd_info.cmd_size = 0x20b8;
    cmd_info.data_type = 0x23;
    cmd_info.cmd = NULL;
    s32Ret = SAMPLE_USER_INIT_MIPITx(fd, &cmd_info);
    if (s32Ret != HI_SUCCESS) {
        return s32Ret;
    }
    usleep(1000);

    cmd_info.devno = 0;
    cmd_info.cmd_size = 0x10b9;
    cmd_info.data_type = 0x23;
    cmd_info.cmd = NULL;
    s32Ret = SAMPLE_USER_INIT_MIPITx(fd, &cmd_info);
    if (s32Ret != HI_SUCCESS) {
        return s32Ret;
    }
    usleep(1000);

    cmd_info.devno = 0;
    cmd_info.cmd_size = 0x78c1;
    cmd_info.data_type = 0x23;
    cmd_info.cmd = NULL;
    s32Ret = SAMPLE_USER_INIT_MIPITx(fd, &cmd_info);
    if (s32Ret != HI_SUCCESS) {
        return s32Ret;
    }
    usleep(1000);

    cmd_info.devno = 0;
    cmd_info.cmd_size = 0x78c2;
    cmd_info.data_type = 0x23;
    cmd_info.cmd = NULL;
    s32Ret = SAMPLE_USER_INIT_MIPITx(fd, &cmd_info);
    if (s32Ret != HI_SUCCESS) {
        return s32Ret;
    }
    usleep(1000);

    cmd_info.devno = 0;
    cmd_info.cmd_size = 0x88d0;
    cmd_info.data_type = 0x23;
    cmd_info.cmd = NULL;
    s32Ret = SAMPLE_USER_INIT_MIPITx(fd, &cmd_info);
    if (s32Ret != HI_SUCCESS) {
        return s32Ret;
    }
    usleep(1000);
    usleep(100000);

    memset(m_buf, 0, 50);
    m_buf[0] = 0xE0; m_buf[1] = 0x00; m_buf[2] = 0x19; m_buf[3] = 0x02;
    cmd_info.devno = 0;
    cmd_info.cmd_size = 4;
    cmd_info.data_type = 0x29;
    cmd_info.cmd = m_buf;
    s32Ret = SAMPLE_USER_INIT_MIPITx(fd, &cmd_info);
    if (s32Ret != HI_SUCCESS) {
        return s32Ret;
    }
    usleep(1000);
    usleep(1000);

    memset(m_buf, 0, 50);
    m_buf[0] = 0xE1; m_buf[1] = 0x05; m_buf[2] = 0xA0; m_buf[3] = 0x07; m_buf[4] = 0xA0; m_buf[5] = 0x04;
    m_buf[6] = 0xA0; m_buf[7] = 0x06;  m_buf[8] = 0xA0; m_buf[9] = 0x00; m_buf[10] = 0x44; m_buf[11] = 0x44;
    cmd_info.devno = 0;
    cmd_info.cmd_size = 12;
    cmd_info.data_type = 0x29;
    cmd_info.cmd = m_buf;
    s32Ret = SAMPLE_USER_INIT_MIPITx(fd, &cmd_info);
    if (s32Ret != HI_SUCCESS) {
        return s32Ret;
    }
    usleep(1000);

    memset(m_buf, 0, 50);
    m_buf[0] = 0xE2; m_buf[1] = 0x00; m_buf[2] = 0x00; m_buf[3] = 0x00; m_buf[4] = 0x00; m_buf[5] = 0x00; m_buf[6] = 0x00;
    m_buf[7] = 0x00;  m_buf[8] = 0x00; m_buf[9] = 0x00; m_buf[10] = 0x00; m_buf[11] = 0x00; m_buf[12] = 0x00;
    cmd_info.devno = 0;
    cmd_info.cmd_size = 13;
    cmd_info.data_type = 0x29;
    cmd_info.cmd = m_buf;
    s32Ret = SAMPLE_USER_INIT_MIPITx(fd, &cmd_info);
    if (s32Ret != HI_SUCCESS) {
        return s32Ret;
    }
    usleep(1000);

    memset(m_buf, 0, 50);
    m_buf[0] = 0xE3; m_buf[1] = 0x00; m_buf[2] = 0x00; m_buf[3] = 0x33; m_buf[4] = 0x33;
    cmd_info.devno = 0;
    cmd_info.cmd_size = 5;
    cmd_info.data_type = 0x29;
    cmd_info.cmd = m_buf;
    s32Ret = SAMPLE_USER_INIT_MIPITx(fd, &cmd_info);
    if (s32Ret != HI_SUCCESS) {
        return s32Ret;
    }
    usleep(1000);

    memset(m_buf, 0, 50);
    m_buf[0] = 0xE4; m_buf[1] = 0x44; m_buf[2] = 0x44;
    cmd_info.devno = 0;
    cmd_info.cmd_size = 3;
    cmd_info.data_type = 0x29;
    cmd_info.cmd = m_buf;
    s32Ret = SAMPLE_USER_INIT_MIPITx(fd, &cmd_info);
    if (s32Ret != HI_SUCCESS) {
        return s32Ret;
    }
    usleep(1000);

    memset(m_buf, 0, 50);
    m_buf[0] = 0xE5; m_buf[1] = 0x0D; m_buf[2] = 0x31; m_buf[3] = 0xC8; m_buf[4] = 0xAF; m_buf[5] = 0x0F; m_buf[6] = 0x33; m_buf[7] = 0xC8;
    m_buf[8] = 0xAF; m_buf[9] = 0x09; m_buf[10] = 0x2D; m_buf[11] = 0xC8; m_buf[12] = 0xAF; m_buf[13] = 0x0B; m_buf[14] = 0x2F; m_buf[15] = 0xC8; m_buf[16] = 0xAF;
    cmd_info.devno = 0;
    cmd_info.cmd_size = 17;
    cmd_info.data_type = 0x29;
    cmd_info.cmd = m_buf;
    s32Ret = SAMPLE_USER_INIT_MIPITx(fd, &cmd_info);
    if (s32Ret != HI_SUCCESS) {
        return s32Ret;
    }
    usleep(1000);

    memset(m_buf, 0, 50);
    m_buf[0] = 0xE6; m_buf[1] = 0x00; m_buf[2] = 0x00; m_buf[3] = 0x33; m_buf[4] = 0x33;
    cmd_info.devno = 0;
    cmd_info.cmd_size = 5;
    cmd_info.data_type = 0x29;
    cmd_info.cmd = m_buf;
    s32Ret = SAMPLE_USER_INIT_MIPITx(fd, &cmd_info);
    if (s32Ret != HI_SUCCESS) {
        return s32Ret;
    }
    usleep(1000);

    memset(m_buf, 0, 50);
    m_buf[0] = 0xE7; m_buf[1] = 0x44; m_buf[2] = 0x44;
    cmd_info.devno = 0;
    cmd_info.cmd_size = 3;
    cmd_info.data_type = 0x29;
    cmd_info.cmd = m_buf;
    s32Ret = SAMPLE_USER_INIT_MIPITx(fd, &cmd_info);
    if (s32Ret != HI_SUCCESS) {
        return s32Ret;
    }
    usleep(1000);

    memset(m_buf, 0, 50);
    m_buf[0] = 0xE8; m_buf[1] = 0x0C; m_buf[2] = 0x30; m_buf[3] = 0xC8; m_buf[4] = 0xAF; m_buf[5] = 0x0E; m_buf[6] = 0x32; m_buf[7] = 0xC8;
    m_buf[8] = 0xAF; m_buf[9] = 0x08; m_buf[10] = 0x2C; m_buf[11] = 0xC8; m_buf[12] = 0xAF; m_buf[13] = 0x0A; m_buf[14] = 0x2E; m_buf[15] = 0xC8; m_buf[16] = 0xAF;
    cmd_info.devno = 0;
    cmd_info.cmd_size = 17;
    cmd_info.data_type = 0x29;
    cmd_info.cmd = m_buf;
    s32Ret = SAMPLE_USER_INIT_MIPITx(fd, &cmd_info);
    if (s32Ret != HI_SUCCESS) {
        return s32Ret;
    }
    usleep(1000);

    memset(m_buf, 0, 50);
    m_buf[0] = 0xEB; m_buf[1] = 0x02; m_buf[2] = 0x00; m_buf[3] = 0xE4; m_buf[4] = 0xE4; m_buf[5] = 0x44; m_buf[6] = 0x00; m_buf[7] = 0x40;
    cmd_info.devno = 0;
    cmd_info.cmd_size = 8;
    cmd_info.data_type = 0x29;
    cmd_info.cmd = m_buf;
    s32Ret = SAMPLE_USER_INIT_MIPITx(fd, &cmd_info);
    if (s32Ret != HI_SUCCESS) {
        return s32Ret;
    }
    usleep(1000);

    memset(m_buf, 0, 50);
    m_buf[0] = 0xEC; m_buf[1] = 0x3C; m_buf[2] = 0x00;
    cmd_info.devno = 0;
    cmd_info.cmd_size = 3;
    cmd_info.data_type = 0x29;
    cmd_info.cmd = m_buf;
    s32Ret = SAMPLE_USER_INIT_MIPITx(fd, &cmd_info);
    if (s32Ret != HI_SUCCESS) {
        return s32Ret;
    }
    usleep(1000);

    memset(m_buf, 0, 50);
    m_buf[0] = 0xED; m_buf[1] = 0xAB; m_buf[2] = 0x89; m_buf[3] = 0x76; m_buf[4] = 0x54; m_buf[5] = 0x01; m_buf[6] = 0xFF; m_buf[7] = 0xFF;
    m_buf[8] = 0xFF; m_buf[9] = 0xFF; m_buf[10] = 0xFF; m_buf[11] = 0xFF; m_buf[12] = 0x10; m_buf[13] = 0x45; m_buf[14] = 0x67; m_buf[15] = 0x98; m_buf[16] = 0xBA;
    cmd_info.devno = 0;
    cmd_info.cmd_size = 17;
    cmd_info.data_type = 0x29;
    cmd_info.cmd = m_buf;
    s32Ret = SAMPLE_USER_INIT_MIPITx(fd, &cmd_info);
    if (s32Ret != HI_SUCCESS) {
        return s32Ret;
    }
    usleep(1000);

    memset(m_buf, 0, 50);
    m_buf[0] = 0xEF; m_buf[1] = 0x08; m_buf[2] = 0x08; m_buf[3] = 0x08; m_buf[4] = 0x45; m_buf[5] = 0x3F; m_buf[6] = 0x54;
    cmd_info.devno = 0;
    cmd_info.cmd_size = 7;
    cmd_info.data_type = 0x29;
    cmd_info.cmd = m_buf;
    s32Ret = SAMPLE_USER_INIT_MIPITx(fd, &cmd_info);
    if (s32Ret != HI_SUCCESS) {
        return s32Ret;
    }
    usleep(1000);

    memset(m_buf, 0, 50);
    m_buf[0] = 0xFF; m_buf[1] = 0x77; m_buf[2] = 0x01; m_buf[3] = 0x00; m_buf[4] = 0x00; m_buf[5] = 0x00;
    cmd_info.devno = 0;
    cmd_info.cmd_size = 6;
    cmd_info.data_type = 0x29;
    cmd_info.cmd = m_buf;
    s32Ret = SAMPLE_USER_INIT_MIPITx(fd, &cmd_info);
    if (s32Ret != HI_SUCCESS) {
        return s32Ret;
    }
    usleep(1000);

    memset(m_buf, 0, 50);
    m_buf[0] = 0xFF; m_buf[1] = 0x77; m_buf[2] = 0x01; m_buf[3] = 0x00; m_buf[4] = 0x00; m_buf[5] = 0x13;
    cmd_info.devno = 0;
    cmd_info.cmd_size = 6;
    cmd_info.data_type = 0x29;
    cmd_info.cmd = m_buf;
    s32Ret = SAMPLE_USER_INIT_MIPITx(fd, &cmd_info);
    if (s32Ret != HI_SUCCESS) {
        return s32Ret;
    }
    usleep(1000);

    memset(m_buf, 0, 50);
    m_buf[0] = 0xE8; m_buf[1] = 0x00; m_buf[2] = 0x0E; m_buf[3] = 0x11;
    cmd_info.devno = 0;
    cmd_info.cmd_size = 4;
    cmd_info.data_type = 0x29;
    cmd_info.cmd = m_buf;
    s32Ret = SAMPLE_USER_INIT_MIPITx(fd, &cmd_info);
    if (s32Ret != HI_SUCCESS) {
        return s32Ret;
    }
    usleep(1000);
    usleep(120000);

    memset(m_buf, 0, 50);
    m_buf[0] = 0xE8; m_buf[1] = 0x00; m_buf[2] = 0x0C;
    cmd_info.devno = 0;
    cmd_info.cmd_size = 3;
    cmd_info.data_type = 0x29;
    cmd_info.cmd = m_buf;
    s32Ret = SAMPLE_USER_INIT_MIPITx(fd, &cmd_info);
    if (s32Ret != HI_SUCCESS) {
        return s32Ret;
    }
    usleep(1000);
    usleep(10000);

    memset(m_buf, 0, 50);
    m_buf[0] = 0xE8; m_buf[1] = 0x00; m_buf[2] = 0x00;
    cmd_info.devno = 0;
    cmd_info.cmd_size = 3;
    cmd_info.data_type = 0x29;
    cmd_info.cmd = m_buf;
    s32Ret = SAMPLE_USER_INIT_MIPITx(fd, &cmd_info);
    if (s32Ret != HI_SUCCESS) {
        return s32Ret;
    }
    usleep(1000);
    usleep(10000);

    memset(m_buf, 0, 50);
    m_buf[0] = 0xFF; m_buf[1] = 0x77; m_buf[2] = 0x01; m_buf[3] = 0x00; m_buf[4] = 0x00; m_buf[5] = 0x00;
    cmd_info.devno = 0;
    cmd_info.cmd_size = 6;
    cmd_info.data_type = 0x29;
    cmd_info.cmd = m_buf;
    s32Ret = SAMPLE_USER_INIT_MIPITx(fd, &cmd_info);
    if (s32Ret != HI_SUCCESS) {
        return s32Ret;
    }
    usleep(1000);
    usleep(10000);

    cmd_info.devno = 0;
    cmd_info.cmd_size = 0x11;
    cmd_info.data_type = 0x05;
    cmd_info.cmd = NULL;
    s32Ret = SAMPLE_USER_INIT_MIPITx(fd, &cmd_info);
    if (s32Ret != HI_SUCCESS) {
        return s32Ret;
    }
    usleep(1000);
    usleep(150000);

    cmd_info.devno = 0;
    cmd_info.cmd_size = 0x29;
    cmd_info.data_type = 0x05;
    cmd_info.cmd = NULL;
    s32Ret = SAMPLE_USER_INIT_MIPITx(fd, &cmd_info);
    if (s32Ret != HI_SUCCESS) {
        return s32Ret;
    }
    usleep(1000);
    usleep(50000);

    return HI_SUCCESS;
}

HI_S32 SAMPLE_VO_ENABLE_MIPITx(HI_S32 fd)
{
    HI_S32 s32Ret;

    s32Ret = ioctl(fd, HI_MIPI_TX_ENABLE);
    if (s32Ret != HI_SUCCESS) {
        printf("MIPI_TX enable failed\n");
        return s32Ret;
    }

    return s32Ret;
}

HI_S32 SAMPLE_VO_DISABLE_MIPITx(HI_S32 fd)
{
    HI_S32 s32Ret;
    s32Ret = ioctl(fd, HI_MIPI_TX_DISABLE);
    if (s32Ret != HI_SUCCESS) {
        printf("MIPI_TX disable failed\n");
        return s32Ret;
    }

    return s32Ret;
}

HI_S32 SAMPLE_VO_CONFIG_MIPI(HI_S32* mipiFD)
{
    HI_S32 s32Ret;
    /* SET MIPI BAKCLIGHT */
    HI_S32  fd;
    /* CONFIG MIPI PINUMX */

    /* Reset MIPI */
    /* OPEN MIPI FD */
    fd = SAMPLE_OPEN_MIPITx_FD();
    if (fd < 0) {
        return HI_FAILURE;
    }
    *mipiFD = fd;

    /* SET MIPI Tx Dev ATTR */
    s32Ret = SAMPLE_SET_MIPITx_Dev_ATTR(fd);
    if (s32Ret != HI_SUCCESS) {
        return s32Ret;
    }

    usleep(10000);
    system("cd /sys/class/gpio/;echo 5 > export;echo out > gpio5/direction;echo 1 > gpio5/value");
    usleep(200000);
    system("echo 0 > /sys/class/gpio/gpio5/value");
    usleep(200000);
    system("echo 1 > /sys/class/gpio/gpio5/value");
    usleep(20000);

    /* CONFIG MIPI Tx INITIALIZATION SEQUENCE */
    s32Ret = SAMPLE_VO_INIT_MIPITx_Screen(fd);
    if (s32Ret != HI_SUCCESS) {
        return s32Ret;
    }

    /* ENABLE MIPI Tx DEV */
    s32Ret = SAMPLE_VO_ENABLE_MIPITx(fd);
    if (s32Ret != HI_SUCCESS) {
        return s32Ret;
    }

    return s32Ret;
}

HI_S32 SAMPLE_COMM_VO_GetWH_MIPI(VO_INTF_SYNC_E enIntfSync, HI_U32* pu32W, HI_U32* pu32H, HI_U32* pu32Frm)
{
    switch (enIntfSync)
    {
    case VO_OUTPUT_PAL:
        *pu32W = 720;
        *pu32H = 576;
        *pu32Frm = 25;
        break;
    case VO_OUTPUT_NTSC:
        *pu32W = 720;
        *pu32H = 480;
        *pu32Frm = 30;
        break;
    case VO_OUTPUT_1080P24:
        *pu32W = 1920;
        *pu32H = 1080;
        *pu32Frm = 24;
        break;
    case VO_OUTPUT_1080P25:
        *pu32W = 1920;
        *pu32H = 1080;
        *pu32Frm = 25;
        break;
    case VO_OUTPUT_1080P30:
        *pu32W = 1920;
        *pu32H = 1080;
        *pu32Frm = 30;
        break;
    case VO_OUTPUT_720P50:
        *pu32W = 1280;
        *pu32H = 720;
        *pu32Frm = 50;
        break;
    case VO_OUTPUT_720P60:
        *pu32W = 1280;
        *pu32H = 720;
        *pu32Frm = 60;
        break;
    case VO_OUTPUT_1080I50:
        *pu32W = 1920;
        *pu32H = 1080;
        *pu32Frm = 50;
        break;
    case VO_OUTPUT_1080I60:
        *pu32W = 1920;
        *pu32H = 1080;
        *pu32Frm = 60;
        break;
    case VO_OUTPUT_1080P50:
        *pu32W = 1920;
        *pu32H = 1080;
        *pu32Frm = 50;
        break;
    case VO_OUTPUT_1080P60:
        *pu32W = 1920;
        *pu32H = 1080;
        *pu32Frm = 60;
        break;
    case VO_OUTPUT_576P50:
        *pu32W = 720;
        *pu32H = 576;
        *pu32Frm = 50;
        break;
    case VO_OUTPUT_480P60:
        *pu32W = 720;
        *pu32H = 480;
        *pu32Frm = 60;
        break;
    case VO_OUTPUT_800x600_60:
        *pu32W = 800;
        *pu32H = 600;
        *pu32Frm = 60;
        break;
    case VO_OUTPUT_1024x768_60:
        *pu32W = 1024;
        *pu32H = 768;
        *pu32Frm = 60;
        break;
    case VO_OUTPUT_1280x1024_60:
        *pu32W = 1280;
        *pu32H = 1024;
        *pu32Frm = 60;
        break;
    case VO_OUTPUT_1366x768_60:
        *pu32W = 1366;
        *pu32H = 768;
        *pu32Frm = 60;
        break;
    case VO_OUTPUT_1440x900_60:
        *pu32W = 1440;
        *pu32H = 900;
        *pu32Frm = 60;
        break;
    case VO_OUTPUT_1280x800_60:
        *pu32W = 1280;
        *pu32H = 800;
        *pu32Frm = 60;
        break;
    case VO_OUTPUT_1600x1200_60:
        *pu32W = 1600;
        *pu32H = 1200;
        *pu32Frm = 60;
        break;
    case VO_OUTPUT_1680x1050_60:
        *pu32W = 1680;
        *pu32H = 1050;
        *pu32Frm = 60;
        break;
    case VO_OUTPUT_1920x1200_60:
        *pu32W = 1920;
        *pu32H = 1200;
        *pu32Frm = 60;
        break;
    case VO_OUTPUT_640x480_60:
        *pu32W = 640;
        *pu32H = 480;
        *pu32Frm = 60;
        break;
    case VO_OUTPUT_960H_PAL:
        *pu32W = 960;
        *pu32H = 576;
        *pu32Frm = 50;
        break;
    case VO_OUTPUT_960H_NTSC:
        *pu32W = 960;
        *pu32H = 480;
        *pu32Frm = 60;
        break;
    case VO_OUTPUT_1920x2160_30:
        *pu32W = 1920;
        *pu32H = 2160;
        *pu32Frm = 30;
        break;
    case VO_OUTPUT_2560x1440_30:
        *pu32W = 2560;
        *pu32H = 1440;
        *pu32Frm = 30;
        break;
    case VO_OUTPUT_2560x1600_60:
        *pu32W = 2560;
        *pu32H = 1600;
        *pu32Frm = 60;
        break;
    case VO_OUTPUT_3840x2160_30:
        *pu32W = 3840;
        *pu32H = 2160;
        *pu32Frm = 30;
        break;
    case VO_OUTPUT_3840x2160_60:
        *pu32W = 3840;
        *pu32H = 2160;
        *pu32Frm = 60;
        break;
    case VO_OUTPUT_320x240_60:
        *pu32W = 320;
        *pu32H = 240;
        *pu32Frm = 60;
        break;
    case VO_OUTPUT_320x240_50:
        *pu32W = 320;
        *pu32H = 240;
        *pu32Frm = 50;
        break;
    case VO_OUTPUT_240x320_50:
        *pu32W = 240;
        *pu32H = 320;
        *pu32Frm = 50;
        break;
    case VO_OUTPUT_240x320_60:
        *pu32W = 240;
        *pu32H = 320;
        *pu32Frm = 60;
        break;
    case VO_OUTPUT_800x600_50:
        *pu32W = 800;
        *pu32H = 600;
        *pu32Frm = 50;
        break;
    case VO_OUTPUT_720x1280_60:
        *pu32W = 720;
        *pu32H = 1280;
        *pu32Frm = 60;
        break;
    case VO_OUTPUT_1080x1920_60:
        *pu32W = 1080;
        *pu32H = 1920;
        *pu32Frm = 60;
        break;
    case VO_OUTPUT_7680x4320_30:
        *pu32W = 7680;
        *pu32H = 4320;
        *pu32Frm = 30;
        break;
    case VO_OUTPUT_USER:
        *pu32W = 800;
        *pu32H = 480;
        *pu32Frm = 60;
        break;
    default:
        SAMPLE_PRT("vo enIntfSync %d not support!\n", enIntfSync);
        return HI_FAILURE;
    }

    return HI_SUCCESS;
}

HI_S32 SAMPLE_COMM_VO_StartDev_MIPI(VO_DEV VoDev, VO_PUB_ATTR_S* pstPubAttr)
{
    HI_S32 s32Ret = HI_SUCCESS;
    VO_USER_INTFSYNC_INFO_S stUserInfo = { 0 };

    stUserInfo.bClkReverse = HI_TRUE;
    stUserInfo.u32DevDiv = 1;
    stUserInfo.u32PreDiv = 1;
    stUserInfo.stUserIntfSyncAttr.enClkSource = VO_CLK_SOURCE_PLL;
    stUserInfo.stUserIntfSyncAttr.stUserSyncPll.u32Fbdiv = 244;
    stUserInfo.stUserIntfSyncAttr.stUserSyncPll.u32Frac = 0x1A36;
    stUserInfo.stUserIntfSyncAttr.stUserSyncPll.u32Refdiv = 4;
    stUserInfo.stUserIntfSyncAttr.stUserSyncPll.u32Postdiv1 = 7;
    stUserInfo.stUserIntfSyncAttr.stUserSyncPll.u32Postdiv2 = 7;

    HI_U32 u32Framerate = 60;

    s32Ret = HI_MPI_VO_SetPubAttr(VoDev, pstPubAttr);
    if (s32Ret != HI_SUCCESS)
    {
        SAMPLE_PRT("failed with %#x!\n", s32Ret);
        return HI_FAILURE;
    }

    s32Ret = HI_MPI_VO_SetDevFrameRate(VoDev, u32Framerate);
    if (s32Ret != HI_SUCCESS)
    {
        SAMPLE_PRT("failed with %#x!\n", s32Ret);
        return HI_FAILURE;
    }

    s32Ret = HI_MPI_VO_SetUserIntfSyncInfo(VoDev, &stUserInfo);
    if (s32Ret != HI_SUCCESS)
    {
        SAMPLE_PRT("failed with %#x!\n", s32Ret);
        return HI_FAILURE;
    }

    s32Ret = HI_MPI_VO_Enable(VoDev);
    if (s32Ret != HI_SUCCESS)
    {
        SAMPLE_PRT("failed with %#x!\n", s32Ret);
        return HI_FAILURE;
    }

    return s32Ret;
}


HI_S32 SAMPLE_COMM_VO_StartChn_MIPI(VO_LAYER VoLayer, SAMPLE_VO_MODE_E enMode)
{
    HI_S32 i;
    HI_S32 s32Ret = HI_SUCCESS;
    HI_U32 u32WndNum = 0;
    HI_U32 u32Square = 0;
    HI_U32 u32Row = 0;
    HI_U32 u32Col = 0;
    HI_U32 u32Width = 0;
    HI_U32 u32Height = 0;
    VO_CHN_ATTR_S         stChnAttr;
    VO_VIDEO_LAYER_ATTR_S stLayerAttr;

    switch (enMode)
    {
    case VO_MODE_1MUX:
        u32WndNum = 1;
        u32Square = 1;
        break;
    case VO_MODE_2MUX:
        u32WndNum = 2;
        u32Square = 2;
        break;
    case VO_MODE_4MUX:
        u32WndNum = 4;
        u32Square = 2;
        break;
    case VO_MODE_8MUX:
        u32WndNum = 8;
        u32Square = 3;
        break;
    case VO_MODE_9MUX:
        u32WndNum = 9;
        u32Square = 3;
        break;
    case VO_MODE_16MUX:
        u32WndNum = 16;
        u32Square = 4;
        break;
    case VO_MODE_25MUX:
        u32WndNum = 25;
        u32Square = 5;
        break;
    case VO_MODE_36MUX:
        u32WndNum = 36;
        u32Square = 6;
        break;
    case VO_MODE_49MUX:
        u32WndNum = 49;
        u32Square = 7;
        break;
    case VO_MODE_64MUX:
        u32WndNum = 64;
        u32Square = 8;
        break;
    case VO_MODE_2X4:
        u32WndNum = 8;
        u32Square = 3;
        u32Row = 4;
        u32Col = 2;
        break;
    default:
        SAMPLE_PRT("failed with %#x!\n", s32Ret);
        return HI_FAILURE;
    }

    s32Ret = HI_MPI_VO_GetVideoLayerAttr(VoLayer, &stLayerAttr);
    if (s32Ret != HI_SUCCESS)
    {
        SAMPLE_PRT("failed with %#x!\n", s32Ret);
        return HI_FAILURE;
    }
    u32Width = stLayerAttr.stImageSize.u32Width;
    u32Height = stLayerAttr.stImageSize.u32Height;
    SAMPLE_PRT("u32Width:%d, u32Height:%d, u32Square:%d\n", u32Width, u32Height, u32Square);
    for (i = 0; i < u32WndNum; i++)
    {
        if (enMode == VO_MODE_1MUX ||
            enMode == VO_MODE_2MUX ||
            enMode == VO_MODE_4MUX ||
            enMode == VO_MODE_8MUX ||
            enMode == VO_MODE_9MUX ||
            enMode == VO_MODE_16MUX ||
            enMode == VO_MODE_25MUX ||
            enMode == VO_MODE_36MUX ||
            enMode == VO_MODE_49MUX ||
            enMode == VO_MODE_64MUX)
        {
            stChnAttr.stRect.s32X = ALIGN_DOWN((u32Width / u32Square) * (i % u32Square), 2);
            stChnAttr.stRect.s32Y = ALIGN_DOWN((u32Height / u32Square) * (i / u32Square), 2);
            stChnAttr.stRect.u32Width = ALIGN_DOWN(u32Width / u32Square, 2);
            stChnAttr.stRect.u32Height = ALIGN_DOWN(u32Height / u32Square, 2);
            stChnAttr.u32Priority = 0;
            stChnAttr.bDeflicker = HI_FALSE;
        }
        else if (enMode == VO_MODE_2X4)
        {
            stChnAttr.stRect.s32X = ALIGN_DOWN((u32Width / u32Col) * (i % u32Col), 2);
            stChnAttr.stRect.s32Y = ALIGN_DOWN((u32Height / u32Row) * (i / u32Col), 2);
            stChnAttr.stRect.u32Width = ALIGN_DOWN(u32Width / u32Col, 2);
            stChnAttr.stRect.u32Height = ALIGN_DOWN(u32Height / u32Row, 2);
            stChnAttr.u32Priority = 0;
            stChnAttr.bDeflicker = HI_FALSE;
        }

        s32Ret = HI_MPI_VO_SetChnAttr(VoLayer, i, &stChnAttr);
        if (s32Ret != HI_SUCCESS)
        {
            printf("%s(%d):failed with %#x!\n", \
                __FUNCTION__, __LINE__, s32Ret);
            return HI_FAILURE;
        }

        s32Ret = HI_MPI_VO_SetChnRotation(VoLayer, i, ROTATION_90);
        if (s32Ret != HI_SUCCESS)
        {
            printf("%s(%d):failed with %#x!\n", \
                __FUNCTION__, __LINE__, s32Ret);
            return HI_FAILURE;
        }

        s32Ret = HI_MPI_VO_EnableChn(VoLayer, i);
        if (s32Ret != HI_SUCCESS)
        {
            SAMPLE_PRT("failed with %#x!\n", s32Ret);
            return HI_FAILURE;
        }
    }

    return HI_SUCCESS;
}

HI_S32 SAMPLE_COMM_VO_StartVO_MIPI(SAMPLE_VO_CONFIG_S* pstVoConfig)
{
    RECT_S                 stDefDispRect = { 0, 0, 800, 480 };
    SIZE_S                 stDefImageSize = { 800, 480 };

    /*******************************************
    * VO device VoDev# information declaration.
    ********************************************/
    VO_DEV                 VoDev = 0;
    VO_LAYER               VoLayer = 0;
    SAMPLE_VO_MODE_E       enVoMode = 0;
    VO_INTF_TYPE_E         enVoIntfType = VO_INTF_HDMI;
    VO_PART_MODE_E         enVoPartMode = VO_PART_MODE_SINGLE;
    VO_PUB_ATTR_S          stVoPubAttr = { 0 };
    VO_VIDEO_LAYER_ATTR_S  stLayerAttr = { 0 };
    VO_CSC_S               stVideoCSC = { 0 };
    HI_S32                 s32Ret = HI_SUCCESS;

    if (NULL == pstVoConfig)
    {
        SAMPLE_PRT("Error:argument can not be NULL\n");
        return HI_FAILURE;
    }
    VoDev = pstVoConfig->VoDev;
    VoLayer = pstVoConfig->VoDev;
    enVoMode = pstVoConfig->enVoMode;
    enVoIntfType = pstVoConfig->enVoIntfType;
    enVoPartMode = pstVoConfig->enVoPartMode;

    /********************************
    * Set and start VO device VoDev#.
    *********************************/
    stVoPubAttr.enIntfType = VO_INTF_MIPI;
    stVoPubAttr.enIntfSync = VO_OUTPUT_USER;
    stVoPubAttr.stSyncInfo.bSynm = 0;
    stVoPubAttr.stSyncInfo.bIop = 1;
    stVoPubAttr.stSyncInfo.u8Intfb = 0;

    stVoPubAttr.stSyncInfo.u16Hmid = 1;
    stVoPubAttr.stSyncInfo.u16Bvact = 1;
    stVoPubAttr.stSyncInfo.u16Bvbb = 1;
    stVoPubAttr.stSyncInfo.u16Bvfb = 1;

    stVoPubAttr.stSyncInfo.bIdv = 0;
    stVoPubAttr.stSyncInfo.bIhs = 0;
    stVoPubAttr.stSyncInfo.bIvs = 0;

    stVoPubAttr.stSyncInfo.u16Hact = 480;
    stVoPubAttr.stSyncInfo.u16Hbb = 60;
    stVoPubAttr.stSyncInfo.u16Hfb = 50;
    stVoPubAttr.stSyncInfo.u16Hpw = 10;
    stVoPubAttr.stSyncInfo.u16Vact = 800;
    stVoPubAttr.stSyncInfo.u16Vbb = 24;
    stVoPubAttr.stSyncInfo.u16Vfb = 20;
    stVoPubAttr.stSyncInfo.u16Vpw = 4;
    stVoPubAttr.u32BgColor = pstVoConfig->u32BgColor;

    s32Ret = SAMPLE_COMM_VO_StartDev_MIPI(VoDev, &stVoPubAttr);
    if (HI_SUCCESS != s32Ret)
    {
        SAMPLE_PRT("SAMPLE_COMM_VO_StartDev_MIPI failed!\n");
        return s32Ret;
    }

    /******************************
    * Set and start layer VoDev#.
    ********************************/

    s32Ret = SAMPLE_COMM_VO_GetWH_MIPI(stVoPubAttr.enIntfSync,
        &stLayerAttr.stDispRect.u32Width, &stLayerAttr.stDispRect.u32Height,
        &stLayerAttr.u32DispFrmRt);
    if (HI_SUCCESS != s32Ret)
    {
        SAMPLE_PRT("SAMPLE_COMM_VO_GetWH_MIPI failed!\n");
        SAMPLE_COMM_VO_StopDev(VoDev);
        return s32Ret;
    }
    stLayerAttr.bClusterMode = HI_FALSE;
    stLayerAttr.bDoubleFrame = HI_FALSE;
    stLayerAttr.enPixFormat = pstVoConfig->enPixFormat;

    stLayerAttr.stDispRect.s32X = 0;
    stLayerAttr.stDispRect.s32Y = 0;

    /******************************
    Set display rectangle if changed.
    ********************************/
    if (0 != memcmp(&pstVoConfig->stDispRect, &stDefDispRect, sizeof(RECT_S)))
    {
        memcpy(&stLayerAttr.stDispRect, &pstVoConfig->stDispRect, sizeof(RECT_S));
    }

    /******************************
    Set image size if changed.
    ********************************/
    if (0 != memcmp(&pstVoConfig->stImageSize, &stDefImageSize, sizeof(SIZE_S)))
    {
        memcpy(&stLayerAttr.stImageSize, &pstVoConfig->stImageSize, sizeof(SIZE_S));
    }
    stLayerAttr.stImageSize.u32Width = stLayerAttr.stDispRect.u32Width = 480;
    stLayerAttr.stImageSize.u32Height = stLayerAttr.stDispRect.u32Height = 800;
    stLayerAttr.enDstDynamicRange = pstVoConfig->enDstDynamicRange;

    if (pstVoConfig->u32DisBufLen)
    {
        s32Ret = HI_MPI_VO_SetDisplayBufLen(VoLayer, pstVoConfig->u32DisBufLen);
        if (HI_SUCCESS != s32Ret)
        {
            SAMPLE_PRT("HI_MPI_VO_SetDisplayBufLen failed with %#x!\n", s32Ret);
            SAMPLE_COMM_VO_StopDev(VoDev);
            return s32Ret;
        }
    }
    if (VO_PART_MODE_MULTI == enVoPartMode)
    {
        s32Ret = HI_MPI_VO_SetVideoLayerPartitionMode(VoLayer, enVoPartMode);
        if (HI_SUCCESS != s32Ret)
        {
            SAMPLE_PRT("HI_MPI_VO_SetVideoLayerPartitionMode failed!\n");
            SAMPLE_COMM_VO_StopDev(VoDev);
            return s32Ret;
        }
    }

    s32Ret = SAMPLE_COMM_VO_StartLayer(VoLayer, &stLayerAttr);
    if (HI_SUCCESS != s32Ret)
    {
        SAMPLE_PRT("SAMPLE_COMM_VO_Start video layer failed!\n");
        SAMPLE_COMM_VO_StopDev(VoDev);
        return s32Ret;
    }

    if (VO_INTF_MIPI == enVoIntfType)
    {
        s32Ret = HI_MPI_VO_GetVideoLayerCSC(VoLayer, &stVideoCSC);
        if (HI_SUCCESS != s32Ret)
        {
            SAMPLE_PRT("HI_MPI_VO_GetVideoLayerCSC failed!\n");
            SAMPLE_COMM_VO_StopDev(VoDev);
            return s32Ret;
        }
        stVideoCSC.enCscMatrix = VO_CSC_MATRIX_BT709_TO_RGB_PC;
        s32Ret = HI_MPI_VO_SetVideoLayerCSC(VoLayer, &stVideoCSC);
        if (HI_SUCCESS != s32Ret)
        {
            SAMPLE_PRT("HI_MPI_VO_SetVideoLayerCSC failed!\n");
            SAMPLE_COMM_VO_StopDev(VoDev);
            return s32Ret;
        }
    }

    /******************************
    * start vo channels.
    ********************************/
    s32Ret = SAMPLE_COMM_VO_StartChn_MIPI(VoLayer, enVoMode);
    if (HI_SUCCESS != s32Ret)
    {
        SAMPLE_PRT("SAMPLE_COMM_VO_StartChn failed!\n");
        SAMPLE_COMM_VO_StopLayer(VoLayer);
        SAMPLE_COMM_VO_StopDev(VoDev);
        return s32Ret;
    }

    return HI_SUCCESS;
}


//HI_S32 SAMPLE_VO_DISABLE_MIPITx(HI_S32 fd)
//{
//    HI_S32 s32Ret;
//    s32Ret = ioctl(fd, HI_MIPI_TX_DISABLE);
//    if (s32Ret != HI_SUCCESS) {
//        printf("MIPI_TX disable failed\n");
//        return s32Ret;
//    }
//
//    return s32Ret;
//}
