#include "hi_comm_vb.h"
#include "mpi_vb.h"
#include "hi_buffer.h"
#include "hi_comm_video.h"
#include "hi_defines.h"
#include "SR_nnie.h"
#include "sample_comm.h"
#include "MIPI.h"
#include "hi_common.h"
#include "sample_comm_svp.h"
#include <pthread.h>
#include <sys/prctl.h>
#include "mpi_nnie.h"
#include "SR_Task.h"
#include "rtsp_agent.h"
typedef struct hiSAMPLE_IVE_SWITCH_S
{
	HI_BOOL bVenc;
	HI_BOOL bVo_HDMI;
	HI_BOOL bVo_MIPI;
}SAMPLE_IVE_SWITCH_S;
SAMPLE_IVE_SWITCH_S pstSwitch = { .bVenc = HI_TRUE,.bVo_HDMI = HI_FALSE,.bVo_MIPI = HI_FALSE};
SAMPLE_VI_CONFIG_S stViConfig;
int fd = 0;
SAMPLE_VO_CONFIG_S stVoConfig;
uint32_t CP_SYS_Init(SAMPLE_VI_CONFIG_S* pstViConfig ,SIZE_S *pasSize)
{
	uint32_t s32Ret = 0;
	SIZE_S astSize[VPSS_CHN_NUM];
	PIC_SIZE_E aenSize[VPSS_CHN_NUM];
	VB_CONFIG_S stVbConfig;
	PIC_SIZE_E enExtPicSize = PIC_CIF;
	HI_S32 s32ViCnt = 1;
	VI_DEV ViDev0 = 0;
	VI_PIPE ViPipe0 = 0;
	VI_CHN ViChn = 0;
	WDR_MODE_E enWDRMode = WDR_MODE_NONE;
	DYNAMIC_RANGE_E enDynamicRange = DYNAMIC_RANGE_SDR8;
	PIXEL_FORMAT_E enPixFormat = PIXEL_FORMAT_YVU_SEMIPLANAR_420;
	VIDEO_FORMAT_E enVideoFormat = VIDEO_FORMAT_LINEAR;
	COMPRESS_MODE_E enCompressMode = COMPRESS_MODE_NONE;
	VI_VPSS_MODE_E enMastPipeMode = VI_ONLINE_VPSS_OFFLINE;

	memset(pstViConfig, 0, sizeof(*pstViConfig));

	SAMPLE_COMM_VI_GetSensorInfo(pstViConfig);
	pstViConfig->s32WorkingViNum = s32ViCnt;

	pstViConfig->as32WorkingViId[0] = 0;
	pstViConfig->astViInfo[0].stSnsInfo.MipiDev = SAMPLE_COMM_VI_GetComboDevBySensor(pstViConfig->astViInfo[0].stSnsInfo.enSnsType, 0);
	pstViConfig->astViInfo[0].stSnsInfo.s32BusId = 0;

	pstViConfig->astViInfo[0].stDevInfo.ViDev = ViDev0;
	pstViConfig->astViInfo[0].stDevInfo.enWDRMode = enWDRMode;

	pstViConfig->astViInfo[0].stPipeInfo.enMastPipeMode = enMastPipeMode;
	pstViConfig->astViInfo[0].stPipeInfo.aPipe[0] = ViPipe0;
	pstViConfig->astViInfo[0].stPipeInfo.aPipe[1] = -1;
	pstViConfig->astViInfo[0].stPipeInfo.aPipe[2] = -1;
	pstViConfig->astViInfo[0].stPipeInfo.aPipe[3] = -1;

	pstViConfig->astViInfo[0].stChnInfo.ViChn = ViChn;
	pstViConfig->astViInfo[0].stChnInfo.enPixFormat = enPixFormat;
	pstViConfig->astViInfo[0].stChnInfo.enDynamicRange = enDynamicRange;
	pstViConfig->astViInfo[0].stChnInfo.enVideoFormat = enVideoFormat;
	pstViConfig->astViInfo[0].stChnInfo.enCompressMode = enCompressMode;

	s32Ret = SAMPLE_COMM_VI_GetSizeBySensor(pstViConfig->astViInfo[0].stSnsInfo.enSnsType, &aenSize[0]);
	CP_CHECK_EXPR_GOTO(HI_SUCCESS != s32Ret, VB_FAIL_0,
		"Error(%#x),SAMPLE_COMM_VI_GetSizeBySensor failed!\n", s32Ret);
	aenSize[1] = enExtPicSize;
	for (uint8_t i = 0; i < VPSS_CHN_NUM -1; i++)
	{
		aenSize[i + 1] = enExtPicSize;
	}
	aenSize[1] = aenSize[0];
	for (uint8_t i = 0; i < VPSS_CHN_NUM; i++)
	{
		VB_CAL_CONFIG_S stCalConfig;
		s32Ret = SAMPLE_COMM_SYS_GetPicSize(aenSize[i], &astSize[i]);
		CP_CHECK_EXPR_GOTO(HI_SUCCESS != s32Ret, VB_FAIL_0,
			"SAMPLE_COMM_SYS_GetPicSize failed,Error(%#x)!\n", s32Ret);
		COMMON_GetPicBufferConfig(astSize[i].u32Width, astSize[i].u32Height, PIXEL_FORMAT_YVU_SEMIPLANAR_420, DATA_BITWIDTH_8, COMPRESS_MODE_NONE, DEFAULT_ALIGN, &stCalConfig);
		stVbConfig.astCommPool[i].u32BlkCnt = 16;
		stVbConfig.astCommPool[i].u64BlkSize = stCalConfig.u32VBSize;
		stVbConfig.astCommPool[i].enRemapMode = VB_REMAP_MODE_NOCACHE;
	    //stVbConfig.astCommPool[i].acMmzName = 
	}
	s32Ret = SAMPLE_COMM_SYS_Init(&stVbConfig);
	CP_CHECK_EXPR_GOTO(HI_SUCCESS != s32Ret, VB_FAIL_1,
		"SAMPLE_COMM_SYS_Init failed,Error(%#x)!\n", s32Ret);
	for (uint8_t i = 0; i < VPSS_CHN_NUM;i++)
	{
		pasSize[i].u32Height = astSize[i].u32Height;
		pasSize[i].u32Width = astSize[i].u32Width;
	}

	return s32Ret;
VB_FAIL_1:
	SAMPLE_COMM_SYS_Exit();
VB_FAIL_0:
	return s32Ret;
}
uint32_t CP_VPSS_Init(SIZE_S * pasSize)
{
	uint32_t s32Ret = 0;
	VPSS_GRP VpssGrp = 0;
	HI_BOOL abChnEnable[VPSS_CHN_NUM] = { 0 };
	VPSS_GRP_ATTR_S stVpssGrpAttr = { 0 };
	VPSS_CHN_ATTR_S astVpssChnAttr[VPSS_CHN_NUM] = { 0 };
	stVpssGrpAttr.u32MaxH = 1536;
	stVpssGrpAttr.u32MaxW = 2596;
	stVpssGrpAttr.bNrEn = HI_FALSE;
	stVpssGrpAttr.enDynamicRange = DYNAMIC_RANGE_SDR8;
	stVpssGrpAttr.enPixelFormat = PIXEL_FORMAT_YVU_SEMIPLANAR_420;
	stVpssGrpAttr.stFrameRate.s32DstFrameRate = -1;
	stVpssGrpAttr.stFrameRate.s32SrcFrameRate = -1;
	for (uint8_t i = 0; i < VPSS_CHN_NUM; i++)
	{
		abChnEnable[i] = HI_TRUE;
		astVpssChnAttr[i].bFlip = HI_FALSE;
		astVpssChnAttr[i].bMirror = HI_FALSE;
		astVpssChnAttr[i].enChnMode = VPSS_CHN_MODE_USER;
		astVpssChnAttr[i].enCompressMode = COMPRESS_MODE_NONE;
		astVpssChnAttr[i].enDynamicRange = DYNAMIC_RANGE_SDR8;
		astVpssChnAttr[i].enPixelFormat = PIXEL_FORMAT_YVU_SEMIPLANAR_420;
		astVpssChnAttr[i].enVideoFormat = VIDEO_FORMAT_LINEAR;
		astVpssChnAttr[i].stAspectRatio.enMode= ASPECT_RATIO_NONE;
		astVpssChnAttr[i].stFrameRate.s32DstFrameRate = -1;
		astVpssChnAttr[i].stFrameRate.s32SrcFrameRate = -1;
		astVpssChnAttr[i].u32Depth = 1;
		astVpssChnAttr[i].u32Height = pasSize[i].u32Height;
		astVpssChnAttr[i].u32Width = pasSize[i].u32Width;
	}
	s32Ret = SAMPLE_COMM_VPSS_Start(VpssGrp, &abChnEnable,
		&stVpssGrpAttr, &astVpssChnAttr);
	if (s32Ret)
	{
		return s32Ret;
	}
	VPSS_CROP_INFO_S stCropInfo;
	stCropInfo.bEnable = HI_TRUE;
	stCropInfo.enCropCoordinate = VPSS_CROP_ABS_COOR;
	stCropInfo.stCropRect.s32X = (pasSize[1].u32Width - VPSS_CHN1_Width) / 2;
	stCropInfo.stCropRect.s32Y = (pasSize[1].u32Height - VPSS_CHN1_Height) / 2;
	stCropInfo.stCropRect.u32Height = VPSS_CHN1_Height;
	stCropInfo.stCropRect.u32Width = VPSS_CHN1_Width;
	s32Ret = HI_MPI_VPSS_SetChnCrop(VpssGrp, 1, &stCropInfo);
	CP_CHECK_PRINT(s32Ret != HI_SUCCESS, "HI_MPI_VPSS_SetChnCrop fail %#x\n", s32Ret);
	return s32Ret;
}
HI_S32 HIDMI_StartVo(HI_VOID)
{
	HI_S32 s32Ret;
	VO_DEV VoDev = SAMPLE_VO_DEV_DHD0;
	VO_LAYER VoLayer = 0;
	VO_PUB_ATTR_S stVoPubAttr;
	VO_VIDEO_LAYER_ATTR_S stLayerAttr;
	SAMPLE_VO_MODE_E enVoMode = VO_MODE_1MUX;
	HI_U32 u32DisBufLen = 3;

	stVoPubAttr.enIntfSync = VO_OUTPUT_1080P30;
	stVoPubAttr.enIntfType = VO_INTF_HDMI;
	stVoPubAttr.u32BgColor = COLOR_RGB_BLUE;
	s32Ret = SAMPLE_COMM_VO_StartDev(VoDev, &stVoPubAttr);
	CP_CHECK_EXPR_GOTO(HI_SUCCESS != s32Ret, VO_FAIL_0,
		"SAMPLE_COMM_VO_StartDev failed,Error(%#x)!\n", s32Ret);

	s32Ret = SAMPLE_COMM_VO_HdmiStart(stVoPubAttr.enIntfSync);
	CP_CHECK_EXPR_GOTO(HI_SUCCESS != s32Ret, VO_FAIL_1,
		"SAMPLE_COMM_VO_HdmiStart failed,Error(%#x)!\n", s32Ret);

	s32Ret = SAMPLE_COMM_VO_GetWH(stVoPubAttr.enIntfSync, &stLayerAttr.stDispRect.u32Width,
		&stLayerAttr.stDispRect.u32Height, &stLayerAttr.u32DispFrmRt);
	CP_CHECK_EXPR_GOTO(HI_SUCCESS != s32Ret, VO_FAIL_2,
		"SAMPLE_COMM_VO_GetWH failed,Error(%#x)!\n", s32Ret);

	s32Ret = HI_MPI_VO_SetDisplayBufLen(VoLayer, u32DisBufLen);
	CP_CHECK_EXPR_GOTO(HI_SUCCESS != s32Ret, VO_FAIL_2,
		"HI_MPI_VO_SetDisplayBufLen failed,Error(%#x)!\n", s32Ret);

	stLayerAttr.stDispRect.s32X = 0;
	stLayerAttr.stDispRect.s32Y = 0;
	stLayerAttr.stImageSize.u32Width = stLayerAttr.stDispRect.u32Width;
	stLayerAttr.stImageSize.u32Height = stLayerAttr.stDispRect.u32Height;
	stLayerAttr.bDoubleFrame = HI_FALSE;
	stLayerAttr.bClusterMode = HI_FALSE;
	stLayerAttr.enPixFormat = PIXEL_FORMAT_YVU_SEMIPLANAR_420;
	stLayerAttr.enDstDynamicRange = DYNAMIC_RANGE_SDR8;

	s32Ret = SAMPLE_COMM_VO_StartLayer(VoLayer, &stLayerAttr);
	CP_CHECK_EXPR_GOTO(HI_SUCCESS != s32Ret, VO_FAIL_2,
		"SAMPLE_COMM_VO_StartLayer failed,Error(%#x)!\n", s32Ret);

	s32Ret = SAMPLE_COMM_VO_StartChn(VoLayer, enVoMode);
	CP_CHECK_EXPR_GOTO(HI_SUCCESS != s32Ret, VO_FAIL_3,
		"SAMPLE_COMM_VO_StartChn failed,Error(%#x)!\n", s32Ret);

	return s32Ret;
VO_FAIL_3:
	SAMPLE_COMM_VO_StopLayer(VoLayer);
VO_FAIL_2:
	SAMPLE_COMM_VO_HdmiStop();
VO_FAIL_1:
	SAMPLE_COMM_VO_StopDev(VoDev);
VO_FAIL_0:
	return s32Ret;
}
HI_VOID HDMI_StopVo(HI_VOID)
{
	VO_DEV VoDev = SAMPLE_VO_DEV_DHD0;
	VO_LAYER VoLayer = 0;
	SAMPLE_VO_MODE_E enVoMode = VO_MODE_1MUX;

	(HI_VOID)SAMPLE_COMM_VO_StopChn(VoDev, enVoMode);
	(HI_VOID)SAMPLE_COMM_VO_StopLayer(VoLayer);
	SAMPLE_COMM_VO_HdmiStop();
	(HI_VOID)SAMPLE_COMM_VO_StopDev(VoDev);
}
int32_t VI_VPSS_VENC_VO_Init()
{
	HI_S32 s32Ret = 0;
	SIZE_S asSize[VPSS_CHN_NUM];
	s32Ret = CP_SYS_Init(&stViConfig, &asSize[0]);
	CP_CHECK_PRINT(HI_SUCCESS != s32Ret,
		"Error(%#x),CP_SYS_Init failed!\n", s32Ret);
	s32Ret = SAMPLE_COMM_VI_SetParam(&stViConfig);
	CP_CHECK_PRINT(HI_SUCCESS != s32Ret,
		"Error(%#x),SAMPLE_COMM_VI_SetParam failed!\n", s32Ret);
	s32Ret = SAMPLE_COMM_VI_StartVi(&stViConfig);
	CP_CHECK_EXPR_GOTO(HI_SUCCESS != s32Ret, END_INIT_1,
		"Error(%#x),SAMPLE_COMM_VI_StartVi failed!\n", s32Ret);
	VI_PIPE_NRX_PARAM_S stNrx;
	s32Ret = HI_MPI_VI_GetPipeNRXParam(0, &stNrx);
	if (HI_SUCCESS != s32Ret)
	{
		printf("HI_MPI_VI_GetPipeNRXParam failed.\n");
		return HI_FAILURE;
	}
	stNrx.stNRXParamV1.stNRXManualV1.stNRXParamV1.SFy[0].STR = 13;
	stNrx.stNRXParamV1.stNRXManualV1.stNRXParamV1.SFy[1].STR = 13;
	stNrx.stNRXParamV1.stNRXManualV1.stNRXParamV1.SFy[2].STR = 13;
	stNrx.stNRXParamV1.stNRXManualV1.stNRXParamV1.SFy[0].SBS[0] = 0;
	stNrx.stNRXParamV1.stNRXManualV1.stNRXParamV1.SFy[0].SBS[1] = 0;
	stNrx.stNRXParamV1.stNRXManualV1.stNRXParamV1.SFy[0].SBS[2] = 0;
	stNrx.stNRXParamV1.stNRXManualV1.stNRXParamV1.SFy[0].STH[0] = 0;
	stNrx.stNRXParamV1.stNRXManualV1.stNRXParamV1.SFy[0].STH[1] = 0;
	stNrx.stNRXParamV1.stNRXManualV1.stNRXParamV1.SFy[0].STH[2] = 0;
	stNrx.stNRXParamV1.stNRXManualV1.stNRXParamV1.SFy[0].SDS[0] = 0;
	stNrx.stNRXParamV1.stNRXManualV1.stNRXParamV1.SFy[0].SDS[1] = 0;
	stNrx.stNRXParamV1.stNRXManualV1.stNRXParamV1.SFy[0].SDS[2] = 0;
	stNrx.stNRXParamV1.stNRXManualV1.stNRXParamV1.SFy[1].SBS[0] = 0;
	stNrx.stNRXParamV1.stNRXManualV1.stNRXParamV1.SFy[1].SBS[1] = 0;
	stNrx.stNRXParamV1.stNRXManualV1.stNRXParamV1.SFy[1].SBS[2] = 0;
	stNrx.stNRXParamV1.stNRXManualV1.stNRXParamV1.SFy[1].STH[0] = 0;
	stNrx.stNRXParamV1.stNRXManualV1.stNRXParamV1.SFy[1].STH[1] = 0;
	stNrx.stNRXParamV1.stNRXManualV1.stNRXParamV1.SFy[1].STH[2] = 0;
	stNrx.stNRXParamV1.stNRXManualV1.stNRXParamV1.SFy[1].SDS[0] = 0;
	stNrx.stNRXParamV1.stNRXManualV1.stNRXParamV1.SFy[1].SDS[1] = 0;
	stNrx.stNRXParamV1.stNRXManualV1.stNRXParamV1.SFy[1].SDS[2] = 0;
	stNrx.stNRXParamV1.stNRXManualV1.stNRXParamV1.SFy[2].kPro = 0;
	stNrx.stNRXParamV1.stNRXManualV1.stNRXParamV1.SFy[2].SBF = 0;
	stNrx.stNRXParamV1.stNRXManualV1.stNRXParamV1.SFy[2].STH[0] = 1;
	stNrx.stNRXParamV1.stNRXManualV1.stNRXParamV1.SFy[2].STH[1] = 2;
	stNrx.stNRXParamV1.stNRXManualV1.stNRXParamV1.SFy[2].STH[2] = 4;

	stNrx.stNRXParamV1.stNRXManualV1.stNRXParamV1.SFy[3].kPro = 0;
	stNrx.stNRXParamV1.stNRXManualV1.stNRXParamV1.SFy[3].SBF = 0;
	stNrx.stNRXParamV1.stNRXManualV1.stNRXParamV1.SFy[3].STH[0] = 1;
	stNrx.stNRXParamV1.stNRXManualV1.stNRXParamV1.SFy[3].STH[1] = 2;
	stNrx.stNRXParamV1.stNRXManualV1.stNRXParamV1.SFy[3].STH[2] = 4;
	stNrx.stNRXParamV1.stNRXManualV1.stNRXParamV1.MDy[0].MATH = 0;
	stNrx.stNRXParamV1.stNRXManualV1.stNRXParamV1.MDy[1].MATH = 0;
	stNrx.stNRXParamV1.stNRXManualV1.stNRXParamV1.TFy[0].TFS = 0;
	stNrx.stNRXParamV1.stNRXManualV1.stNRXParamV1.TFy[1].TFS = 0;

	s32Ret = HI_MPI_VI_SetPipeNRXParam(0, &stNrx);
	if (HI_SUCCESS != s32Ret)
	{
		printf("HI_MPI_VI_SetPipeNRXParam failed with %#x!\n", s32Ret);

	}
	asSize[1].u32Height = 1536;
	asSize[1].u32Width = 2592;
	s32Ret = CP_VPSS_Init(asSize);
	CP_CHECK_EXPR_GOTO(HI_SUCCESS != s32Ret, END_INIT_2,
		"Error(%#x),SAMPLE_IVS_StartVpss failed!\n", s32Ret);
	s32Ret = SAMPLE_COMM_VI_Bind_VPSS(0, 0, 0);
	CP_CHECK_EXPR_GOTO(HI_SUCCESS != s32Ret, END_INIT_3,
		"Error(%#x),SAMPLE_COMM_VI_BindVpss failed!\n", s32Ret);
	//Set vi frame
	VI_CHN_ATTR_S stViChnAttr;
	s32Ret = HI_MPI_VI_GetChnAttr(0, 0, &stViChnAttr);
	CP_CHECK_EXPR_GOTO(HI_SUCCESS != s32Ret, END_INIT_4,
		"Error(%#x),HI_MPI_VI_GetChnAttr failed!\n", s32Ret);

	s32Ret = HI_MPI_VI_SetChnAttr(0, 0, &stViChnAttr);
	CP_CHECK_EXPR_GOTO(HI_SUCCESS != s32Ret, END_INIT_4,
		"Error(%#x),HI_MPI_VI_SetChnAttr failed!\n", s32Ret);
	char choose = 0;
	while (1)
	{
		printf("if Entering any key unless \"H\"choose VO-HDMI,else VO-MIPI\n");
		choose = getchar();
		if (choose)
			if (choose == 'h' || choose == 'H')
			{
				pstSwitch.bVo_HDMI = HI_TRUE;
				pstSwitch.bVo_MIPI = HI_FALSE;
			}
			else
			{
				pstSwitch.bVo_HDMI = HI_FALSE;
				pstSwitch.bVo_MIPI = HI_TRUE;
			}
		break;
	}

	if (pstSwitch.bVo_MIPI == HI_TRUE)
	{
		system("cd /sys/class/gpio/;echo 55 > export;echo out > gpio55/direction;echo 1 > gpio55/value");

		s32Ret = SAMPLE_VO_CONFIG_MIPI(&fd);
		printf("<MIPI_init:0x%x\n", s32Ret);
		if (HI_SUCCESS != s32Ret)
		{
			printf("CONFIG MIPI failed.s32Ret:0x%x !\n", s32Ret);
		}
		/*config vo*/

		SAMPLE_COMM_VO_GetDefConfig(&stVoConfig);
		stVoConfig.enDstDynamicRange = DYNAMIC_RANGE_SDR8;

		stVoConfig.enVoIntfType = VO_INTF_MIPI;
		stVoConfig.enIntfSync = VO_OUTPUT_USER;

		stVoConfig.enPicSize = PIC_2592x1536;

		/*start vo*/
		s32Ret = SAMPLE_COMM_VO_StartVO_MIPI(&stVoConfig);
		printf("vo_start:0x%x\n", s32Ret);
		CP_CHECK_EXPR_GOTO(HI_SUCCESS != s32Ret, END_INIT_5,
			"Error(%#x),SAMPLE_COMM_IVE_StartVo failed!\n", s32Ret);
	}
	else if (pstSwitch.bVo_HDMI == HI_TRUE)
	{
		s32Ret = HIDMI_StartVo();
		CP_CHECK_EXPR_GOTO(HI_SUCCESS != s32Ret, END_INIT_5, "HIDMI_StartVo fail %#x\n", s32Ret);
	}
	VENC_GOP_ATTR_S stGopAttr;
	VENC_CHN VeH264Chn = 0;

	if (HI_TRUE == pstSwitch.bVenc)
	{
		s32Ret = SAMPLE_COMM_VENC_GetGopAttr(VENC_GOPMODE_NORMALP, &stGopAttr);
		CP_CHECK_EXPR_GOTO(HI_SUCCESS != s32Ret, END_INIT_5,
			"Error(%#x),SAMPLE_COMM_VENC_GetGopAttr failed!\n", s32Ret);
		s32Ret = SAMPLE_COMM_VENC_Start(0, PT_H264, PIC_2592x1536, SAMPLE_RC_CBR, 0, HI_FALSE, &stGopAttr);
		CP_CHECK_EXPR_GOTO(HI_SUCCESS != s32Ret, END_INIT_5,
			"Error(%#x),SAMPLE_COMM_VENC_Start failed!\n", s32Ret);
		s32Ret = SAMPLE_COMM_VENC_StartGetStream(&VeH264Chn, 1);
		CP_CHECK_EXPR_GOTO(HI_SUCCESS != s32Ret, END_INIT_6,
			"Error(%#x),SAMPLE_COMM_VENC_StartGetStream failed!\n", s32Ret);
	}
	printf("SAMPLE_COMM_VENC_Start finsh :%d\n", s32Ret);
	return s32Ret;
	VO_DEV VoDev = SAMPLE_VO_DEV_DHD0;
	VO_LAYER VoLayer = 0;
	SAMPLE_VO_MODE_E enVoMode = VO_MODE_1MUX;
	HI_BOOL abChnEnable[VPSS_MAX_PHY_CHN_NUM] = { HI_TRUE,HI_TRUE,HI_FALSE };

END_INIT_6:
	if (HI_TRUE == pstSwitch.bVenc)
	{
		SAMPLE_COMM_VENC_Stop(VeH264Chn);
	}
END_INIT_5:

	if (pstSwitch.bVo_MIPI == HI_TRUE)
	{
		(HI_VOID)SAMPLE_COMM_VO_StopChn(VoDev, enVoMode);
		(HI_VOID)SAMPLE_COMM_VO_StopLayer(VoLayer);
		(HI_VOID)SAMPLE_COMM_VO_StopDev(VoDev);
		SAMPLE_VO_DISABLE_MIPITx(fd);
		close(fd);
		system("echo 0 > /sys/class/gpio/gpio55/value");
		SAMPLE_COMM_VO_StopVO(&stVoConfig);
	}
	else if(pstSwitch.bVo_HDMI == HI_TRUE)
	{
		HDMI_StopVo();
	}
END_INIT_4:
	SAMPLE_COMM_VI_UnBind_VPSS(0, 0, 0);
END_INIT_3:
	SAMPLE_COMM_VPSS_Stop(0,&abChnEnable);
END_INIT_2:
	SAMPLE_COMM_VI_StopVi(&stViConfig);
END_INIT_1:    //system exit
	SAMPLE_COMM_SYS_Exit();
END_INIT_0:
	return s32Ret;
}


int32_t VI_VPSS_VENC_VO_DeInit()
{
	if (HI_TRUE == pstSwitch.bVenc)
	{
		SAMPLE_COMM_VENC_StopGetStream();
		SAMPLE_COMM_VENC_Stop(0);
	}
	if (HI_TRUE == pstSwitch.bVo_MIPI)
	{
		VO_DEV VoDev = SAMPLE_VO_DEV_DHD0;
		VO_LAYER VoLayer = 0;
		SAMPLE_VO_MODE_E enVoMode = VO_MODE_1MUX;

		(HI_VOID)SAMPLE_COMM_VO_StopChn(VoDev, enVoMode);
		(HI_VOID)SAMPLE_COMM_VO_StopLayer(VoLayer);
		(HI_VOID)SAMPLE_COMM_VO_StopDev(VoDev);
		SAMPLE_VO_DISABLE_MIPITx(fd);
		close(fd);
		system("echo 0 > /sys/class/gpio/gpio55/value");
		SAMPLE_COMM_VO_StopVO(&stVoConfig);
	}
	else if(pstSwitch.bVo_HDMI == HI_TRUE)
	{
		HDMI_StopVo();
	}
	SAMPLE_COMM_VI_UnBind_VPSS(stViConfig.astViInfo[0].stPipeInfo.aPipe[0],
		stViConfig.astViInfo[0].stChnInfo.ViChn, 0);
	HI_BOOL abChnEnable[VPSS_MAX_PHY_CHN_NUM] = { HI_TRUE,HI_TRUE,HI_FALSE };
	SAMPLE_COMM_VPSS_Stop(0, &abChnEnable);
	SAMPLE_COMM_VI_StopVi(&stViConfig);
	SAMPLE_COMM_SYS_Exit();
	SAMPLE_COMM_SVP_CheckSysExit();
}
int32_t CP_LoalModel(char* padress,CP_Model * pmodel )
{
	if (padress == NULL)
		return -1;
	int32_t s32Ret = 0;
	FILE *fp = fopen(padress, "rb");
	s32Ret = fseek(fp, 0L, SEEK_END);
	CP_CHECK_EXPR_GOTO(-1 == s32Ret, FAIL_1,"fseek fail %#x\n", s32Ret);
	uint32_t FileSize = ftell(fp);
	fseek(fp, 0, SEEK_SET);
	s32Ret = SAMPLE_COMM_SVP_CreateMemInfo(&pmodel->pstModelBuf, FileSize, 0);
	CP_CHECK_EXPR_GOTO(HI_SUCCESS != s32Ret, FAIL_2, "SAMPLE_COMM_SVP_CreateMemInfo fail :%#x\n", s32Ret);
	printf("SAMPLE_COMM_SVP_CreateMemInfo :%d\n ", s32Ret);
	s32Ret = fread((void*)(pmodel->pstModelBuf.u64VirAddr), FileSize, 1, fp);
	CP_CHECK_EXPR_GOTO(1 != s32Ret, FAIL_2, "fread fail s32Ret:%#x,FileSize:%#x", s32Ret, FileSize);
	s32Ret = HI_MPI_SVP_NNIE_LoadModel(&pmodel->pstModelBuf,&pmodel->Model);
	CP_CHECK_EXPR_GOTO(HI_SUCCESS != s32Ret, FAIL_2, "HI_MPI_SVP_NNIE_LoadModel fail :%#x\n", s32Ret);
	fclose(fp);
	return s32Ret;
FAIL_2:
	SAMPLE_COMM_SVP_DestroyMemInfo(&pmodel->pstModelBuf, 0);
FAIL_1:
	if (fp)
		fclose(fp);
}
void CP_DeLoalModel(CP_Model* pmodel)
{
	SAMPLE_COMM_SVP_DestroyMemInfo(&pmodel->pstModelBuf, 0);
	HI_MPI_SVP_NNIE_UnloadModel(&pmodel->Model);
}
int32_t GET_astNode_Bolb(SVP_NNIE_NODE_S astNode, uint32_t* pBolbSize,uint32_t u32Align)
{
	uint8_t Sizestep = 0;
	uint32_t u32Stride = 0;
	int32_t s32Ret = 0;
	SVP_BLOB_TYPE_E enType = astNode.enType;
	printf("astNode.enType:%d\n", enType);
	if ((enType == SVP_BLOB_TYPE_S32) || (enType == SVP_BLOB_TYPE_VEC_S32)
		|| (enType == SVP_BLOB_TYPE_SEQ_S32))
	{
		Sizestep = sizeof(uint32_t);
	}
	else
	{
		Sizestep = sizeof(uint8_t);
	}
	if (SVP_BLOB_TYPE_SEQ_S32 == enType)
	{
		if (u32Align == 16)
		{

		}
		else if (u32Align == 32)
		{

		}
		printf("enType is  SVP_BLOB_TYPE_SEQ_S32,but not deal ,error\n");
		return 1;
	}
	else
	{
		if (u32Align == 16)
		{
			u32Stride = SAMPLE_SVP_NNIE_ALIGN16(astNode.unShape.stWhc.u32Width * Sizestep);
		}
		else if (u32Align == 32)
		{
			u32Stride = SAMPLE_SVP_NNIE_ALIGN32(astNode.unShape.stWhc.u32Width * Sizestep);
		}
		printf("u32Stride:%d\n", u32Stride);
		*pBolbSize += u32Stride * astNode.unShape.stWhc.u32Height * astNode.unShape.stWhc.u32Chn;
		printf("BolbSize:%d\n", *pBolbSize);
	}
	return s32Ret;
}

int32_t GET_NNIE_Bolb_Size(SVP_NNIE_MODEL_S* Model, uint32_t* pBolbSize, uint32_t* pBolbSize2, uint32_t u32Align)
{
	uint8_t NetSegNum = Model->u32NetSegNum; //�������
	uint32_t u32TotalStep = 0;
	uint32_t u32Stride = 0;
	int32_t s32Ret = 0;
	for (uint8_t i = 0; i < NetSegNum; i++)
	{
		if (i == 0)
		{
			uint8_t SrcNum = Model->astSeg[i].u16SrcNum;
			for (uint8_t j = 0; j < SrcNum; j++)
			{
				s32Ret = GET_astNode_Bolb(Model->astSeg[i].astSrcNode[j], pBolbSize, u32Align);
				CP_CHECK_Return(s32Ret != HI_SUCCESS, s32Ret, "GET_astNode_Bolb fail:%#x\n", s32Ret);
			}
		}
		uint8_t DstNum = Model->astSeg[i].u16DstNum;
		for (uint8_t j = 0; j < DstNum; j++)
		{
			s32Ret = GET_astNode_Bolb(Model->astSeg[i].astDstNode[j], pBolbSize2, u32Align);
			CP_CHECK_Return(s32Ret != HI_SUCCESS, s32Ret, "GET_astNode_Bolb fail:%#x\n", s32Ret);
		}
	}
	return s32Ret;
}

int32_t Get_NNIE_TaskTmpBolbSize( CP_Model * pstModel, uint32_t* pTaskSize, uint32_t* pTmpSize, uint32_t* pBolbSize, uint32_t* pBolbSize2)
{
	int32_t s32Ret = 0;
	s32Ret = HI_MPI_SVP_NNIE_GetTskBufSize(USER_INPUT_NUM, 0,
		&pstModel->Model, pTaskSize, pstModel->Model.u32NetSegNum);
	CP_CHECK_EXPR_GOTO(s32Ret != HI_SUCCESS, GetSize_Fail_1, "HI_MPI_SVP_NNIE_GetTskBufSize fail!:%#x\n", s32Ret);
	*pTmpSize = pstModel->Model.u32TmpBufSize;
	s32Ret = GET_NNIE_Bolb_Size(&pstModel->Model, pBolbSize,  pBolbSize2,16);
	CP_CHECK_EXPR_GOTO(s32Ret != HI_SUCCESS, GetSize_Fail_1, "GET_NNIE_Bolb_Size fail:%#x\n", s32Ret);
	return s32Ret;
GetSize_Fail_1:
	*pTaskSize = 0;
	return s32Ret;

}
int32_t Get_NNIE_Memory(CP_Model *pstModel)
{
	int32_t s32Ret = 0;
	uint32_t TaskSize = 0;
	uint32_t TmpSize = 0;
	uint32_t BolbSize = 0;
	uint32_t BolbSize2 = 0;
	HI_U64 u64PhyAddr = 0;
	uint8_t* ppVirAddr = 0;
	s32Ret = Get_NNIE_TaskTmpBolbSize(pstModel, &TaskSize, &TmpSize, &BolbSize,&BolbSize2);
	uint32_t TotalSize = TaskSize + TmpSize + BolbSize2;
	printf("Total Size:%d\n", TotalSize);
	printf("TaskSize:%d TmpSize:%d BolbSize:%d BolbSize2:%d\n", TaskSize, TmpSize, BolbSize, BolbSize2);
	s32Ret = HI_MPI_SYS_MmzAlloc_Cached((HI_U64*) & u64PhyAddr, (HI_VOID**)&ppVirAddr, "SR_Mmz_Size", NULL, TotalSize);
	CP_CHECK_EXPR_GOTO(s32Ret != HI_SUCCESS, Get_NNIE_Memory_Fail_1,"HI_MPI_SYS_MmzAlloc_Cached fail:%#x\n", s32Ret);
	pstModel->stForwardCtrl.stTskBuf.u32Size = TaskSize;
	pstModel->stForwardCtrl.stTskBuf.u64PhyAddr = u64PhyAddr;
	pstModel->stForwardCtrl.stTskBuf.u64VirAddr = (HI_U64)(HI_UL)ppVirAddr;

	pstModel->stForwardCtrl.stTmpBuf.u32Size = TmpSize;
	pstModel->stForwardCtrl.stTmpBuf.u64PhyAddr = (HI_U64)(u64PhyAddr + TaskSize);
	pstModel->stForwardCtrl.stTmpBuf.u64VirAddr = (HI_U64)(HI_UL)(ppVirAddr + TaskSize);
	pstModel->stForwardCtrl.enNnieId = SVP_NNIE_ID_0;
	pstModel->stForwardCtrl.u32DstNum = pstModel->Model.astSeg[0].u16DstNum;
	pstModel->stForwardCtrl.u32SrcNum = pstModel->Model.astSeg[0].u16SrcNum;
	pstModel->stForwardCtrl.u32NetSegId = 0;

	//pstModel->SrcBlob[0].u64PhyAddr = u64PhyAddr + TaskSize + TmpSize;
	//pstModel->SrcBlob[0].u64VirAddr = (HI_U64)(HI_UL)(ppVirAddr + TaskSize + TmpSize);

	pstModel->DstBlob[0].u64PhyAddr = u64PhyAddr + TaskSize + TmpSize;
	pstModel->DstBlob[0].u64VirAddr = (HI_U64)(HI_UL)(ppVirAddr + TaskSize + TmpSize);


	s32Ret = HI_MPI_SYS_MmzFlushCache(u64PhyAddr, (HI_VOID *) ppVirAddr, TotalSize);
	return s32Ret;
Get_NNIE_Memory_Fail_1:
	HI_MPI_SYS_MmzFree(u64PhyAddr, (HI_VOID*)ppVirAddr);
	return s32Ret;

}

int32_t SR_NNIE_FillForwardInfo(CP_Model* pstModel)
{
	HI_S32 s32Ret = 0;
	pstModel->SrcBlob[0].enType = pstModel->Model.astSeg[0].astSrcNode[0].enType;
	pstModel->SrcBlob[0].u32Num = 1;
	pstModel->SrcBlob[0].unShape.stWhc.u32Height = pstModel->Model.astSeg[0].astSrcNode[0].unShape.stWhc.u32Height;
	pstModel->SrcBlob[0].unShape.stWhc.u32Width = pstModel->Model.astSeg[0].astSrcNode[0].unShape.stWhc.u32Width;
	pstModel->SrcBlob[0].unShape.stWhc.u32Chn = pstModel->Model.astSeg[0].astSrcNode[0].unShape.stWhc.u32Chn;

	pstModel->DstBlob[0].enType = pstModel->Model.astSeg[0].astDstNode[0].enType;
	pstModel->DstBlob[0].u32Num = 1;
	pstModel->DstBlob[0].unShape.stWhc.u32Chn = pstModel->Model.astSeg[0].astDstNode[0].unShape.stWhc.u32Chn;
	pstModel->DstBlob[0].unShape.stWhc.u32Height = pstModel->Model.astSeg[0].astDstNode[0].unShape.stWhc.u32Height;
	pstModel->DstBlob[0].unShape.stWhc.u32Width = pstModel->Model.astSeg[0].astDstNode[0].unShape.stWhc.u32Width;

	s32Ret = HI_MPI_SVP_NNIE_AddTskBuf(&pstModel->stForwardCtrl.stTskBuf);
	CP_CHECK_PRINT(s32Ret != HI_SUCCESS, "HI_MPI_SVP_NNIE_AddTskBuf fail:%#x\n", s32Ret);
	return 0;
}

volatile HI_BOOL SR_Task_Finsh = HI_FALSE;
volatile HI_BOOL Forward_Finsh = HI_FALSE;
volatile HI_BOOL Write_bool = 0;

int32_t SR_main()
{
	int32_t s32Ret = 0;
	s32Ret = VI_VPSS_VENC_VO_Init();
	CP_CHECK_EXPR_GOTO(HI_SUCCESS != s32Ret, END_MAIN_1,
		"Error(%#x),SAMPLE_COMM_VENC_GetGopAttr failed!\n", s32Ret);
	const char* LoadName = "/SR/model/SR.wk";
	CP_Model SRModel = { 0 };
	printf("VI_VPSS_VENC_VO_Init Finsh\n");
	s32Ret = CP_LoalModel(LoadName, &SRModel);
	CP_CHECK_EXPR_GOTO(HI_SUCCESS != s32Ret, END_MAIN_2,
		"Error(%#x),CP_LoalModel failed!\n", s32Ret);
	printf("CP_LoalModel finsh::%d\n", s32Ret);
	s32Ret = Get_NNIE_Memory(&SRModel);
	CP_CHECK_EXPR_GOTO(s32Ret != HI_SUCCESS, END_MAIN_2, "Get_NNIE_Memory fail:%#x\n", s32Ret);
	SR_NNIE_FillForwardInfo(&SRModel);

	printf(" SRModel.DstBlob[0].enType %d\n", SRModel.DstBlob[0].enType);
	printf("%d\n", SRModel.DstBlob[0].u32Num);
	SRModel.DstBlob[0].u32Stride = 1280*4;
	printf("%d\n", SRModel.DstBlob[0].u32Stride);
	printf("%d\n", SRModel.DstBlob[0].unShape.stWhc.u32Chn);
	printf("%d\n", SRModel.DstBlob[0].unShape.stWhc.u32Height);
	printf("%d\n", SRModel.DstBlob[0].unShape.stWhc.u32Width);
	ExtPlugInit();
	pthread_t s_hNnieThread = 0;
	pthread_t s_hNnieThread2 = 0;
	pthread_t s_hNnieThread3 = 0;

	extern void* Switch_Thread(void* pArgs);

	HI_CHAR acThreadName[16] = { 0 };
	snprintf(acThreadName, 16, "SR_NNIE");
	prctl(PR_SET_NAME, (unsigned long)acThreadName, 0, 0, 0);
	pthread_create(&s_hNnieThread, 0, SR_NNIE_FILL_Forward,(void*)&SRModel);

	HI_CHAR acThreadName2[16] = { 0 };
	snprintf(acThreadName2, 16, "DataDeal");
	prctl(PR_SET_NAME, (unsigned long)acThreadName2, 0, 0, 0);
	pthread_create(&s_hNnieThread2, 0, SR_NNIE_DEAL_DATA, (void*)&SRModel);

	HI_CHAR acThreadName3[16] = { 0 };
	snprintf(acThreadName2, 16, "switch");
	prctl(PR_SET_NAME, (unsigned long)acThreadName3, 0, 0, 0);
	pthread_create(&s_hNnieThread3, 0, Switch_Thread, (void*)&SRModel);

	while (1)
	{
		char c = 0;
		c = getchar();
		if (c == 'q'||c=='Q')
		{
			SendFrmMode = 0;
			break;
		}
		else if (c == 't'|| c=='T')
		{
			SendFrmMode = !SendFrmMode;
		}
		else if (c == 'm'||c=='M')
		{
			SendFrmMode = 2;
		}
		else if (c == 'w'||c=='W')
		{
			Write_bool = !Write_bool ;
			printf("Write_bool:::::::%d\n", Write_bool);
		}
		usleep(1000);
	}
	SR_Task_Finsh = HI_TRUE;
	usleep(50000);
	pthread_join(s_hNnieThread, HI_NULL);
	s_hNnieThread = 0;
	pthread_join(s_hNnieThread2, HI_NULL);
	s_hNnieThread2 = 0;
	pthread_join(s_hNnieThread3, HI_NULL);
	s_hNnieThread3 = 0;
	ExtPlugExit();
END_MAIN_2:
	s32Ret = HI_MPI_SVP_NNIE_RemoveTskBuf(&SRModel.stForwardCtrl.stTskBuf);
	CP_CHECK_PRINT(s32Ret != HI_SUCCESS, "HI_MPI_SVP_NNIE_RemoveTskBuf fail:%#x\n", s32Ret);
	HI_MPI_SYS_MmzFree(SRModel.stForwardCtrl.stTskBuf.u64PhyAddr, (HI_VOID*)SRModel.stForwardCtrl.stTskBuf.u64VirAddr);
	CP_DeLoalModel(&SRModel);
END_MAIN_1:
	VI_VPSS_VENC_VO_DeInit();
	SAMPLE_COMM_SVP_CheckSysExit();
	return s32Ret;

}



