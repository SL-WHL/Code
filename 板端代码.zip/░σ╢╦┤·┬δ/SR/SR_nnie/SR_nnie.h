#pragma once
#include "hi_comm_svp.h"
#include "hi_nnie.h"
#include "mpi_nnie.h"

#define VPSS_CHN_NUM 2
#define VPSS_CHN1_Width 320
#define VPSS_CHN1_Height 180



#define CP_CHECK_EXPR_GOTO(expr, label, fmt...)\
do\
{\
    if(expr)\
    {\
        printf(fmt);\
        goto label;\
    }\
}while(0)
#define CP_CHECK_PRINT(expr, fmt...)\
do\
{\
    if(expr)\
    {\
        printf(fmt);\
    }\
}while(0)
#define CP_CHECK_Return(expr, s32Ret ,fmt...)\
do\
{\
    if(expr)\
    {\
        printf(fmt);\
        return s32Ret;\
    }\
}while(0)

/*16Byte align*/
#define SAMPLE_SVP_NNIE_ALIGN_16 16
#define SAMPLE_SVP_NNIE_ALIGN16(u32Num) ((u32Num + SAMPLE_SVP_NNIE_ALIGN_16-1) / SAMPLE_SVP_NNIE_ALIGN_16*SAMPLE_SVP_NNIE_ALIGN_16)
/*32Byte align*/
#define SAMPLE_SVP_NNIE_ALIGN_32 32
#define SAMPLE_SVP_NNIE_ALIGN32(u32Num) ((u32Num + SAMPLE_SVP_NNIE_ALIGN_32-1) / SAMPLE_SVP_NNIE_ALIGN_32*SAMPLE_SVP_NNIE_ALIGN_32)

#define MAX_INPUT_NUM (16)
#define USER_INPUT_NUM (1)


//assert(USER_INPUT_NUM <= MAX_INPUT_NUM) :"USER_INPUT_NUM need Less than or equal to MAX_INPUT_NUM";

typedef struct NNIE_MODEL{
    SVP_SRC_MEM_INFO_S pstModelBuf;
    SVP_NNIE_MODEL_S Model;
    SVP_SRC_BLOB_S SrcBlob[USER_INPUT_NUM];
    SVP_DST_BLOB_S DstBlob[USER_INPUT_NUM];
    SVP_NNIE_FORWARD_CTRL_S stForwardCtrl;
}CP_Model;
