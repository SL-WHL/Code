/*
 * Copyright (c) 2021 HiSilicon (Shanghai) Technologies CO., LIMITED.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "rtsp_agent.h"
#include <pthread.h>
#include <sys/prctl.h>
#define MAX_STR_SIZE 255

static RtspAic g_rtsp;
static bool StartVenc(RtspAic *self);
static void VencEvent(void* user, int fd, uint32_t evts);
static void ConfigVenc(RtspAic *self);

static void StoptVenc(RtspAic *self);

static void RtspOnStrmOff(void* user)
{
	RtspAic *self = &g_rtsp;
    self->vo_started = false;
	self->working = false;
    //EmStop(self->emon); // ????????????????????????
    //EmDestroy(self->emon);
	StoptVenc(self);
	//if(self->vpssWorking){
	//	VpssStop(&self->vpssCfg);
	//}
    return;
}

static void RtspOnVpss(void* user, int fd, uint32_t evts){
 //   RtspAic *self = (RtspAic*)user;
 //   assert(fd == self->vpssFd);
	//VIDEO_FRAME_INFO_S frm;
	//int ret;
 //   EvtChkRet(evts, FDE_IN, fd);
	//if(!self->vo_started)
	//	return;
 //   ret = HI_MPI_VPSS_GetChnFrame(self->vpssGrp, self->vpssChn, &frm, 0);
 //   HI_EXP_RET_NONE(ret, "HI_MPI_VPSS_GetChnFrame FAIL, err=%#x, grp=%d, chn=%d\n",
	//ret, self->vpssGrp, self->vpssChn);
	//if (self->working) {
	//	HI_MPI_VENC_SendFrame(RTSP_VENC_CH_NUM, &frm, -1);
	//}
	//HI_MPI_VPSS_ReleaseChnFrame(self->vpssGrp, self->vpssChn, &frm);
}

static bool RtspOnStrmOn(void* user, int vencChn, PAYLOAD_TYPE_E codecType, int width, int height)
{	
    RtspAic *self = &g_rtsp;
    int ret;
	char source_name[MAX_STR_SIZE];
	self->working = true;
	self->vpssWorking = false;
	self->vpssFd = -1;
	memset(source_name,0,MAX_STR_SIZE);
	sprintf(source_name,"%s",RTSP_CH_NAME);
	
	RtspServerStart(source_name,RTSP_CH_PORT_ID);
	if(self->vo_started){
		printf("rtsp has started!\n");
		return true;
	}
    assert(width > 0 && height > 0);
    self->srcWidth = width;
    self->srcHeight = height;
	ConfigVideo(self->srcWidth,self->srcHeight);
	printf("self->srcWidth %d self->srcHeight %d \n",self->srcWidth,self->srcHeight);
    self->vo_started = true;

	//config venc
	ConfigVenc(self);
	StartVenc(self);
 //   ret = EmCreate(&self->emon);
 //   HI_ASSERT(ret == 0);
 //   ret = EmAddFd(self->emon, self->VencFd, FDE_IN, VencEvent, self);
 //   HI_ASSERT(ret == 0);
	//ret = EmStart(self->emon);
 //   // config vpss
 //   if(!self->vpssWorking){
	//	self->vpssWorking = true;
	//    VpssCfgInit(&self->vpssCfg);
	//	self->vpssGrp = RTSP_VPSS_GRP;
	//    VpssCfgSetGrp(&self->vpssCfg, self->vpssGrp, NULL, RTSP_VPSS_WIDTH_MAX, RTSP_VPSS_HEIGHT_MAX);
	//    self->vpssCfg.grpAttr.bNrEn = HI_FALSE;
	//    self->vpssChn = RTSP_VPSS_CH;
	//    VpssCfgAddChn(&self->vpssCfg, self->vpssChn, NULL, RTSP_CH_WIDTH, RTSP_CH_HEIGHT);
	//	// create vpss
	//	ret = VpssStart(&self->vpssCfg);
	//	if (ret) {
	//		LOGE("VpssStart FAIL, ret=%#x, grp=%d, chn=%d\n", ret, self->vpssGrp, self->vpssChn);
	//		return ret;
	//	}else{
	//		ConfigVideo(RTSP_CH_WIDTH,RTSP_CH_HEIGHT);
	//		self->vpssFd = HI_MPI_VPSS_GetChnFd(self->vpssGrp, self->vpssChn);
	//		assert(self->vpssFd >= 0);
	//		if (EmAddFd(MainEvtMon(), self->vpssFd, FDE_IN, RtspOnVpss, self) < 0) {
	//			assert(0);
	//		}
	//	}
 //   }
    return true;
}

static bool StartVenc(RtspAic *self)
{
    HI_S32 s32Ret = HI_SUCCESS;
    s32Ret = SAMPLE_COMM_VENC_Start(RTSP_VENC_CH_NUM, \
									self->VencConf.enType,  \
									self->VencConf.enSize, \
									self->VencConf.enRcMode, \
									self->VencConf.u32Profile, \
									self->VencConf.bRcnRefShareBuf, \
									&(self->VencConf.stGopAttr));
    if (HI_SUCCESS != s32Ret)
    {
        return false;
    }
	
	self->VencFd = HI_MPI_VENC_GetFd(RTSP_VENC_CH_NUM);
	return true;
}

static void StoptVenc(RtspAic *self)
{
    SAMPLE_COMM_VENC_Stop(RTSP_VENC_CH_NUM);
}

static void ConfigVenc(RtspAic *self){
	self->VencConf.stGopAttr.enGopMode = VENC_GOPMODE_NORMALP;
	self->VencConf.enRcMode = SAMPLE_RC_CBR;
	self->VencConf.enType = PT_H264;
	self->VencConf.u32Profile = RTSP_PROFILE;
	self->VencConf.bRcnRefShareBuf = HI_FALSE;
	self->VencConf.stGopAttr.stNormalP.s32IPQpDelta = VIDEO_IPQDELTA;
	self->VencConf.enSize = PIC_720P;
}

static int GetVencFrame(int vch,VENC_STREAM_S *strm){
    VENC_CHN_STATUS_S stat = { 0 };
    int ret;
    stat.u32CurPacks = 0;
    ret = HI_MPI_VENC_QueryStatus(vch, &stat);
	if(stat.u32CurPacks == 0)
	{
		strm->pstPack = NULL;
		return -1;
	}
    // ??VENC get frame
    strm->u32PackCount = stat.u32CurPacks;
	strm->pstPack = (VENC_PACK_S*)malloc(sizeof(VENC_PACK_S) * stat.u32CurPacks);
    ret = HI_MPI_VENC_GetStream(vch, strm, -1);
	if(!ret)
		return 0;
	HI_MPI_VENC_ReleaseStream(vch, strm);
	if(strm->pstPack != NULL){
		free(strm->pstPack);
		strm->pstPack = NULL;
	}
    return -1;
}

static void RtspOnVideoFrm(void* user, VIDEO_FRAME_INFO_S* frm)
{
	//printf("Rtsp: OnVideoFrm\n");
 //   assert(frm);
 //   RtspAic*self = &g_rtsp;
 //   int ret;

 //   if (!self->working) {
 //       LOGE("onFrm, but not working, discard\n");
 //       return;
 //   }
	//ret = HI_MPI_VPSS_SendFrame(self->vpssGrp, 0, frm, -1);
 //   HI_CHK_GOTO(ret, END, "HI_MPI_VPSS_SendFrame FAIL, ret=%#x, grp=%d\n", ret, self->vpssGrp);
	//
	//END:
 //       LOGD("Rtsp: OnVideoFrm done\n");
}


static const IAicStrmUser G_RTSP_AIC_USER = {
    .OnStrmOn = RtspOnStrmOn,
    .OnStrmOff = RtspOnStrmOff,
    .OnVencFrm = NULL,
    .OnVideoFrm = RtspOnVideoFrm,
};

/*this func is called by rtsp server!*/
void RtspAgentRequestIDR(void){
	RtspAic *self = &g_rtsp;
	if(self->working){
		HI_MPI_VENC_RequestIDR(RTSP_VENC_CH_NUM, HI_TRUE);
	}
}

static void VencEvent(void* user, int fd, uint32_t evts){
	VENC_STREAM_S stStream;	
	int s32Ret = -1;
	int frame_count = 0;
	RtspAic*self = &g_rtsp;
	//if(fd != self->VencFd){
	//	return;
	//}
	stStream.pstPack = NULL;
	s32Ret = GetVencFrame(RTSP_VENC_CH_NUM,&stStream);
	extern volatile uint32_t VencStreamNum ;
	if(!s32Ret){
		for (frame_count = 0; frame_count < stStream.u32PackCount; frame_count++)
		{
			PushFrame(stStream.pstPack[frame_count].pu8Addr + stStream.pstPack[frame_count].u32Offset,
			stStream.pstPack[frame_count].u32Len - stStream.pstPack[frame_count].u32Offset);
		}
		HI_MPI_VENC_ReleaseStream(RTSP_VENC_CH_NUM, &stStream);
		VencStreamNum--;
		printf("VencStreamNum:%d\n", VencStreamNum);
		if(stStream.pstPack != NULL){
			free(stStream.pstPack);
			stStream.pstPack = NULL;
		}
	}
}

static void SigIntHandler(int sig)
{
   /*LOGE("get sig SIGPIPE some pipe write error!\n");*/
}

/*
	???????
*/
static pthread_t RtspThread = 0;
bool Runing = true;
static HI_VOID* RtspRun(HI_VOID* pArgs)
{
    extern volatile uint32_t VencStreamNum;
    while(Runing)
	{
		if(VencStreamNum!=0)
		{
			VencEvent(NULL,0,0);
		}
		hi_usleep(5000);
	}

}
int ExtPlugInit(void)
{
    RtspAic *self = &g_rtsp;
    if (memset_s(self, sizeof(*self), 0, sizeof(*self)) != EOK) {
        assert(0);
    }
	
	// *userItf = &G_RTSP_AIC_USER;
	uint32_t s32Ret = RtspOnStrmOn(NULL,RTSP_VENC_CH_NUM,PT_H264,RTSP_CH_WIDTH,RTSP_CH_HEIGHT);
	HI_CHAR acThreadName2[16] = { 0 };
	snprintf(acThreadName2, 16, "RtspServer");
	prctl(PR_SET_NAME, (unsigned long)acThreadName2, 0, 0, 0);
	pthread_create(&RtspThread, 0, RtspRun, NULL);
    return 0;
}

/**
	??????
*/

int ExtPlugExit(void)
{
	printf("rtsp_agent plug Exit!\n");
	Runing = false;
    pthread_join(RtspThread, HI_NULL);
    RtspThread = 0;
    return 0;
}


