#ifndef RTSP_AGENT_H_
#define RTSP_AGENT_H_
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ioctl.h>
//#include <mpp_help.h>
//#include <aic_mng.h>
#include "sample_comm.h"
#include "stdbool.h"
#include "list.h"
/*rtsp config*/
#define RTSP_CH_PORT_ID   554
#define RTSP_CH_NAME  "h264"
#define RTSP_CH_WIDTH  1280
#define RTSP_CH_HEIGHT  720

#define RTSP_PROFILE  0
#define VIDEO_IPQDELTA 2

#define READ_VENC_INTERVAL_US   1000*20
#define RTSP_VPSS_WIDTH_MAX      2688 // vpss支持的最大width
#define RTSP_VPSS_HEIGHT_MAX     2160 // vpss支持的最大height

#define RTSP_VPSS_GRP   4
#define RTSP_VPSS_CH    1
typedef struct VencFrm {
	VENC_STREAM_S strm;
	VENC_CHN chn;
	struct list_head lnode;
	int refNum;
	uint8_t packs[];
}   VencFrm;
typedef struct IAicStrmUser {
	bool (*OnStrmOn)(void* user, int vencChn, PAYLOAD_TYPE_E codecType, int width, int height);
	void (*OnStrmOff)(void* user);
	void (*OnVencFrm)(void* user, VencFrm* frm); // VENC out frame
	void (*OnVideoFrm)(void* user, VIDEO_FRAME_INFO_S* frm); // VI/VPSS out frame
}IAicStrmUser;
typedef struct VencConfig{
	VENC_GOP_ATTR_S stGopAttr;
	PIC_SIZE_E enSize;
	PAYLOAD_TYPE_E enType;
	SAMPLE_RC_E enRcMode;
	HI_U32  u32Profile;
	HI_BOOL bRcnRefShareBuf;
}VencConfig;

#define RTSP_VENC_CH_NUM 1
typedef struct VpssChnCfg {
	int id; // VpssChn ID
	VPSS_CHN_ATTR_S attr; // VpssChn属性
}   VpssChnCfg;
typedef struct VpssCfg {
	VPSS_GRP grpId; // VpssGrp ID
	VPSS_GRP_ATTR_S grpAttr; // VpssGrp属性

	int chnNum; // 配置使用的chnnel数目
	VpssChnCfg chnCfgs[VPSS_MAX_PHY_CHN_NUM]; // VpssChnCfg数组，前chnNum-1个元素有效
}   VpssCfg;
typedef struct RtspAic {
	bool working; //
	bool vo_started;
	bool vpssWorking;
	HI_S32 vpssFd;
	VpssCfg vpssCfg;
	HI_S32 vpssGrp;
	HI_S32 vpssChn;
	uint32_t srcWidth; //
	uint32_t srcHeight; //
	VencConfig VencConf;	
	HI_S32 VencFd;
	char* bitMapMain;
	char* bitMapSub;
    //EvtMon *emon;
}RtspAic;

extern int RtspServerStart(char* source_name,int port);

extern int PushFrame(unsigned char *h264_buf,int size);

extern int ConfigVideo(int w,int h);
int ExtPlugInit(void);
int ExtPlugExit(void);
#endif
