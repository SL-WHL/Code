#include "SR_Task.h"
#include "SR_nnie.h"
#include "mpi_sys.h"
#include "hi_comm_video.h"
#include "hi_common.h"
#include "sample_comm_svp.h"
#include "mpi_vpss.h"
#include "time.h"
#include "deal_img.h"
#include "mpi_vo.h"
#include "mpi_venc.h"
#include "deal_img.h"
#include "arm_neon.h"
#include "hi_comm_vgs.h"
int32_t SR_NNIE_Forward( CP_Model* pstModel, VIDEO_FRAME_INFO_S* SrcFrm)
{
	int32_t s32Ret = 0;
	pstModel->SrcBlob[0].enType = SVP_BLOB_TYPE_YVU420SP;
	pstModel->SrcBlob[0].u32Num = 1;
	pstModel->SrcBlob[0].u32Stride = SrcFrm->stVFrame.u32Stride[0];
	pstModel->SrcBlob[0].u64PhyAddr = SrcFrm->stVFrame.u64PhyAddr[0];
	pstModel->SrcBlob[0].u64VirAddr = SrcFrm->stVFrame.u64VirAddr[0];
	pstModel->SrcBlob[0].unShape.stWhc.u32Chn = 3;
	pstModel->SrcBlob[0].unShape.stWhc.u32Height = SrcFrm->stVFrame.u32Height;
	pstModel->SrcBlob[0].unShape.stWhc.u32Width = SrcFrm->stVFrame.u32Width;

	SVP_NNIE_HANDLE hSvpNnieHandle = 0;
	s32Ret = HI_MPI_SVP_NNIE_Forward(&hSvpNnieHandle, pstModel->SrcBlob,
		& (pstModel->Model), pstModel->DstBlob,
		&(pstModel->stForwardCtrl),  HI_FALSE);
	CP_CHECK_EXPR_GOTO(s32Ret != HI_SUCCESS, SR_NNIE_Forward_Fail_0, "HI_MPI_SVP_NNIE_Forward fail!:%#x\n", s32Ret);
	HI_BOOL bFinish = HI_FALSE;
	while (1)
	{
		s32Ret = HI_MPI_SVP_NNIE_Query(pstModel->stForwardCtrl.enNnieId, hSvpNnieHandle,
			&bFinish,HI_FALSE);
		if (bFinish == HI_TRUE)
		{
			break;
		}
		usleep(1000);
	}
	return s32Ret;
SR_NNIE_Forward_Fail_0:
	return s32Ret;
} 

int32_t  WriteImg(IVE_IMAGE_S *Img, FILE* fp)
{
	uint32_t s32Ret = 0;
	uint32_t size;
	switch (Img->enType)
	{
	case  IVE_IMAGE_TYPE_U8C3_PLANAR:
		size = Img->u32Height * Img->au32Stride[0]*3;
		fwrite((void*)Img->au64VirAddr[0], 1, size, fp);
		if (s32Ret == size)
		{
			return 0;
		}
		printf("fwrite size:%d\n", s32Ret);
		break;
	default:
		break;
	}
	return -1;
}


VIDEO_FRAME_INFO_S ResFrm;
VIDEO_FRAME_INFO_S stExtFrmInfo;
VIDEO_FRAME_INFO_S GrpINFrm;
volatile uint8_t SendFrmMode = 0;
void* SR_NNIE_FILL_Forward(void* pArgs)
{
	CP_Model * pSRModel = (CP_Model*)pArgs;
	int32_t s32Ret = 0;
	struct timeval start;
	struct timeval stop;
	struct timeval total_time_start = { 0 };
	struct timeval total_time_stop = { 0 };
	static uint32_t count_name = 0;
	while (SR_Task_Finsh == HI_FALSE)
	{
		while (Forward_Finsh == HI_FALSE)
		{
			total_time_start.tv_sec = 0;
			total_time_start.tv_usec = 0;
			gettimeofday(&total_time_start, NULL);
			s32Ret = HI_MPI_VPSS_GetChnFrame(0, 1, &stExtFrmInfo, -1);
			if (HI_SUCCESS != s32Ret)
			{
				printf("Error(%#x),HI_MPI_VPSS_GetChnFrame failed, VPSS_GRP(%d), VPSS_CHN(%d)!\n",
					s32Ret, 0, 1);
				continue;
			}
			s32Ret = HI_MPI_VPSS_GetGrpFrame(0, 0, &GrpINFrm);
			if (HI_SUCCESS != s32Ret)
			{
				printf("HI_MPI_VPSS_GetGrpFrame fail:0x%x\n", s32Ret);
			}
			printf("Write_bool:%d\n", Write_bool);
			if (Write_bool == HI_TRUE)
			{
				IVE_IMAGE_S RGBInImg;
				s32Ret = FrmToRgbImg(&stExtFrmInfo, &RGBInImg);
				if (s32Ret)
				{
					printf("YUVToRGB err\n");
					goto SR_NNIE_FILL_Forward_Fail_0;
				}

				char name[40] = { 0 };
				sprintf(name, "/nfs/input_image/%d.rgb", count_name);
				FILE* fp = fopen((const char*)(&name[0]), "wb+");
				s32Ret = WriteImg(&RGBInImg, fp);
				CP_CHECK_PRINT(s32Ret != HI_SUCCESS, "WriteImg fail %#x\n", s32Ret);
				count_name++;
				fclose(fp);
				
				IveImgDestroy(&RGBInImg);
				printf("write_RGBInImg %s\n", name);
			}
			start.tv_sec = 0;
			start.tv_usec = 0;
			gettimeofday(&start, NULL);
			s32Ret = SR_NNIE_Forward(pSRModel, &stExtFrmInfo);
			CP_CHECK_EXPR_GOTO(s32Ret != HI_SUCCESS, SR_NNIE_FILL_Forward_Fail_0, "SR_NNIE_Forward fail %#x\n", s32Ret);
			Forward_Finsh = HI_TRUE;
			stop.tv_usec = 0;
			gettimeofday(&stop, NULL);
			printf("NNIE time :%d\n", stop.tv_usec - start.tv_usec + 1000000 * (stop.tv_sec - start.tv_sec));
		SR_NNIE_FILL_Forward_Fail_0:
			total_time_stop.tv_sec = 0;
			total_time_stop.tv_usec = 0;
			gettimeofday(&total_time_stop, NULL);
			printf("\nForward total time :%d\n\n", total_time_stop.tv_usec - total_time_start.tv_usec + 1000000 * (total_time_stop.tv_sec - total_time_start.tv_sec));
			if (s32Ret==0)
			{
				continue;
			}
			s32Ret = HI_MPI_VPSS_ReleaseChnFrame(0, 1, &stExtFrmInfo);
			if (s32Ret != HI_SUCCESS)
			{
				printf("Error(%#x),HI_MPI_VPSS_ReleaseChnFrame failed,Grp(%d) chn(%d)!\n",
					s32Ret, 0, 1);
			}
		}
		//printf("Forward_Finsh:%d\n", Forward_Finsh);
		usleep(1000);
	}
	
}
static IVE_IMAGE_S TempImg;
int32_t GET_SR_NNIE_Restlut(CP_Model* pstModel, VIDEO_FRAME_INFO_S *ResFrm)
{
	static HI_BOOL  flag= HI_FALSE;
	int32_t s32Ret = 0;
	// s32Ret = FrmToOrigImg(ResFrm, &TempImg);
	int32_t Height = pstModel->DstBlob[0].unShape.stWhc.u32Height;
	int32_t Width = pstModel->DstBlob[0].unShape.stWhc.u32Width;
	int32_t * pNNIEResVirAddr = (int32_t *)(pstModel->DstBlob[0].u64VirAddr);
	uint32_t ResStride = pstModel->DstBlob[0].u32Stride;
	TempImg.u32Height = Height;
	TempImg.u32Width = Width;
	TempImg.enType = IVE_IMAGE_TYPE_U8C3_PLANAR;
	TempImg.au32Stride[0] = (Width + 15) / 16 * 16;
	uint8_t Chn = pstModel->DstBlob[0].unShape.stWhc.u32Chn;
	if (!flag)
	{
		s32Ret = HI_MPI_SYS_MmzAlloc(&TempImg.au64PhyAddr[0], (void**)&TempImg.au64VirAddr[0], "TempImg Mmz",NULL,
			TempImg.u32Height * TempImg.au32Stride[0] * Chn);
		CP_CHECK_Return(HI_SUCCESS != s32Ret,s32Ret ,"HI_MPI_SYS_MmzAlloc TempImg %#x\n", s32Ret);
		flag = HI_TRUE;
		TempImg.au32Stride[1] = TempImg.au32Stride[0];
		TempImg.au32Stride[2] = TempImg.au32Stride[0];
		TempImg.au64PhyAddr[1] = TempImg.au64PhyAddr[0] + TempImg.au32Stride[0] * Height;
		TempImg.au64PhyAddr[2] = TempImg.au64PhyAddr[1] + TempImg.au32Stride[0] * Height;
		TempImg.au64VirAddr[1] = TempImg.au64VirAddr[0] + TempImg.au32Stride[0] * Height;
		TempImg.au64VirAddr[2] = TempImg.au64VirAddr[1] + TempImg.au32Stride[0] * Height;
 	}
	uint8_t* pImgVirAddr = (uint8_t*)TempImg.au64VirAddr[0];
	uint32_t stride = TempImg.au32Stride[0];
	int32_t DataTemp = 0;
	printf("hight:%d,strde:%d,chn:%d\n", Height, stride, Chn);
	static  uint32x4_t NNIE1;
	static uint32x4_t NNIE2;
	static  uint16x4_t reslut1;
	static  uint16x4_t reslut2;
	static uint16x8_t reslut3;
	static uint8x8_t  reslut;
	for (uint16_t i = 0; i < Height*3; i++)
	{
		for(uint16_t j = 0;j < Width/8;j++)
		{
			//pImgVirAddr[i* Width +j] = pNNIEResVirAddr[i * Width + j] / 4096;
			//DataTemp = (*pNNIEResVirAddr) >> 12;
			//// 
			//if (DataTemp > 255)
			//{
			//	//printf("pNNIEResVirAddr[%d][%d] = %d\n", i, j, DataTemp);
			//	*pImgVirAddr = 255;
			//}
			//else
			//{
			//	*pImgVirAddr = DataTemp;
			//}
			//pImgVirAddr++;
			//pNNIEResVirAddr++;
			{
			    NNIE1 = vld1q_u32(pNNIEResVirAddr);
				pNNIEResVirAddr += 4;
			    NNIE2 = vld1q_u32((pNNIEResVirAddr));
				pNNIEResVirAddr += 4;
			}
			reslut1 = vshrn_n_u32(NNIE1, 12);
			reslut2 = vshrn_n_u32(NNIE2, 12);
			reslut3 = vcombine_u16(reslut1, reslut2);
			reslut = vmovn_u16(reslut3);
			vst1_u8(pImgVirAddr, reslut);
			pImgVirAddr += 8;
		}
		pImgVirAddr += stride - Width;
		pNNIEResVirAddr += ResStride / 4 - Width;
	}
	Forward_Finsh = HI_FALSE;
	IVE_IMAGE_S dst;
	s32Ret = ImgRgbToYuv(&TempImg, &dst, IVE_IMAGE_TYPE_YUV420SP);
	CP_CHECK_PRINT(s32Ret != HI_SUCCESS, "ImgRgbToYuv TempImg %#x \n", s32Ret);
	IVE_HANDLE IveHandle;
	IVE_DATA_S ResIve;
	ResIve.u32Height = ResFrm->stVFrame.u32Height;
	ResIve.u32Width = ResFrm->stVFrame.u32Width;
	ResIve.u64PhyAddr = ResFrm->stVFrame.u64PhyAddr[0];
	ResIve.u32Stride = ResFrm->stVFrame.u32Stride[0];

	IVE_DATA_S SrcIve;
	SrcIve.u32Height = dst.u32Height;
	SrcIve.u32Width = dst.u32Width;
	SrcIve.u64PhyAddr = dst.au64PhyAddr[0];
	SrcIve.u32Stride = dst.au32Stride[0];
	memcpy_s((uint8_t*)ResFrm->stVFrame.u64VirAddr[0], Height * Width * 3 / 2,dst.au64VirAddr[0],
		Height * Width * 3 / 2);
GET_SR_NNIE_Restlut_Fail_0:
	IveImgDestroy(&dst);
	return s32Ret;
}

HI_S32 MyCover(VIDEO_FRAME_INFO_S* input, uint32_t Cover_Width, uint32_t Cover_Hight)
{
	hi_s32 s32Ret = 0;
	VGS_HANDLE Jobhand;
	s32Ret = HI_MPI_VGS_BeginJob(&Jobhand);
	if (s32Ret != 0)
	{
		printf("HI_MPI_VGS_BeginJob Fail:%#x\n", s32Ret);
	}
	VGS_TASK_ATTR_S stTask;
	if (memset_s(&stTask, sizeof(stTask), 0, sizeof(stTask) != EOK))
	{
		HI_ASSERT(0);
	}
	memcpy(&stTask.stImgIn, input, sizeof(VIDEO_FRAME_INFO_S));
	memcpy(&stTask.stImgOut, input, sizeof(VIDEO_FRAME_INFO_S));
	VGS_ADD_COVER_S stVgsAddCover;
	if (memset_s(&stVgsAddCover, sizeof(stVgsAddCover), 0, sizeof(stVgsAddCover)) != EOK) {
		HI_ASSERT(0);
	}
	stVgsAddCover.stQuadRangle.bSolid = HI_FALSE;
	stVgsAddCover.stQuadRangle.u32Thick = 2;
	stVgsAddCover.enCoverType = COVER_QUAD_RANGLE;
	stVgsAddCover.stQuadRangle.stPoint[0].s32X = (input->stVFrame.u32Width - Cover_Width) / 2;
	stVgsAddCover.stQuadRangle.stPoint[0].s32Y = (input->stVFrame.u32Height - Cover_Hight) / 2;

	stVgsAddCover.stQuadRangle.stPoint[1].s32X = (input->stVFrame.u32Width - Cover_Width) / 2 + Cover_Width;
	stVgsAddCover.stQuadRangle.stPoint[1].s32Y = (input->stVFrame.u32Height - Cover_Hight) / 2;

	stVgsAddCover.stQuadRangle.stPoint[2].s32X = (input->stVFrame.u32Width - Cover_Width) / 2 + Cover_Width;
	stVgsAddCover.stQuadRangle.stPoint[2].s32Y = (input->stVFrame.u32Height - Cover_Hight) / 2 + Cover_Hight;

	stVgsAddCover.stQuadRangle.stPoint[3].s32X = (input->stVFrame.u32Width - Cover_Width) / 2;
	stVgsAddCover.stQuadRangle.stPoint[3].s32Y = (input->stVFrame.u32Height - Cover_Hight) / 2 + Cover_Hight;

	stVgsAddCover.u32Color = 0xff0000;
	VGS_DRAW_LINE_S stVgsDrawLine;
	stVgsDrawLine.stStartPoint.s32X = (input->stVFrame.u32Width - Cover_Width) / 2;
	stVgsDrawLine.stEndPoint.s32X = (input->stVFrame.u32Width - Cover_Width) / 2 + Cover_Width;
	stVgsDrawLine.stStartPoint.s32Y = (input->stVFrame.u32Height - Cover_Hight) / 2;
	stVgsDrawLine.stEndPoint.s32Y = (input->stVFrame.u32Height - Cover_Hight) / 2;
	stVgsDrawLine.u32Thick = 8;
	stVgsDrawLine.u32Color = 0xff0000;
	s32Ret = HI_MPI_VGS_AddCoverTask(Jobhand, &stTask,
		&stVgsAddCover);
	if (s32Ret != HI_SUCCESS)
	{
		CP_CHECK_PRINT(s32Ret!=HI_SUCCESS,"HI_MPI_VGS_AddCoverTask fail,Error(%#x)\n", s32Ret);
		HI_MPI_VGS_CancelJob(Jobhand);
		return s32Ret;
	}
	s32Ret = HI_MPI_VGS_EndJob(Jobhand);
	if (s32Ret != HI_SUCCESS)
	{
		CP_CHECK_PRINT(s32Ret != HI_SUCCESS,"HI_MPI_VGS_EndJob fail,Error(%#x)\n", s32Ret);
		HI_MPI_VGS_CancelJob(Jobhand);
		return s32Ret;
	}

	return s32Ret;

}

volatile uint32_t VencStreamNum = 0;
void* SR_NNIE_DEAL_DATA(void* pArgs)
{
	CP_Model* pSRModel = (CP_Model*)pArgs;
	int32_t s32Ret = 0;
	struct timeval start;
	struct timeval stop;
	struct timeval total_time_start = { 0 };
	struct timeval total_time_stop = { 0 };
	s32Ret = MppFrmCreate(&ResFrm,pSRModel->DstBlob[0].unShape.stWhc.u32Width, pSRModel->DstBlob[0].unShape.stWhc.u32Height,
		PIXEL_FORMAT_YVU_SEMIPLANAR_420, DATA_BITWIDTH_8,0,0);
	ResFrm.stVFrame.u32TimeRef = 0;
	if (s32Ret)
	{
		printf("MppFrmCreate ResFrm Fail %#x", s32Ret);
		while (SR_Task_Finsh == HI_FALSE)
		{

		}
	}
	while (SR_Task_Finsh == HI_FALSE)
	{
		while (Forward_Finsh == HI_TRUE)
		{
			gettimeofday(&total_time_start, NULL);
			if (SendFrmMode == 0)
			{
				s32Ret = HI_MPI_VPSS_ReleaseGrpFrame(0, 0, &GrpINFrm);
				CP_CHECK_PRINT(HI_SUCCESS != s32Ret,"HI_MPI_VPSS_ReleaseGrpFrame GrpINFrm:0x%x\n", s32Ret);
				s32Ret = HI_MPI_VPSS_ReleaseChnFrame(0, 1, &stExtFrmInfo);
				CP_CHECK_PRINT(HI_SUCCESS != s32Ret, "HI_MPI_VPSS_ReleaseChnFrame stExtFrmInfo:0x%x\n", s32Ret);
				gettimeofday(&start, NULL);
				s32Ret = GET_SR_NNIE_Restlut(pSRModel, &ResFrm);
				if(s32Ret)
				{
					printf("GET_SR_NNIE_Restlut Fail: %#x\n", s32Ret);
				}
				gettimeofday(&stop, NULL);
				printf("getResilut time :%d\n", stop.tv_usec - start.tv_usec + 1000000 * (stop.tv_sec - start.tv_sec));
				
				printf("SR_NNIE_DEAL_DATA:%d\n", Forward_Finsh);
				s32Ret = HI_MPI_VO_SendFrame(0, 0, &ResFrm, 1000);
				CP_CHECK_PRINT(s32Ret != HI_SUCCESS, "HI_MPI_VO_SendFrame ResFrm %#x\n", s32Ret);
				ResFrm.stVFrame.u32TimeRef += 2;
				//s32Ret = HI_MPI_VENC_SendFrame(1, &ResFrm, 1000);
				//CP_CHECK_PRINT(s32Ret != HI_SUCCESS, "HI_MPI_VENC_SendFrame ResFrm chn:1 %#x\n", s32Ret);
				s32Ret = HI_MPI_VENC_SendFrame(0, &ResFrm, 1000);
				CP_CHECK_PRINT(s32Ret != HI_SUCCESS, "HI_MPI_VENC_SendFrame ResFrm chn:0 %#x\n", s32Ret);
				ResFrm.stVFrame.u32TimeRef += 2;
				s32Ret = HI_MPI_VENC_SendFrame(1, &ResFrm, 1000);
				CP_CHECK_PRINT(s32Ret != HI_SUCCESS, "HI_MPI_VENC_SendFrame ResFrm chn:0 %#x\n", s32Ret);
				VencStreamNum++;
				continue;
			}
			else if (SendFrmMode == 1)
			{
				s32Ret = HI_MPI_VO_SendFrame(0, 0, &stExtFrmInfo, 1000);
				CP_CHECK_PRINT(s32Ret != HI_SUCCESS, "HI_MPI_VO_SendFrame stExtFrmInfo fail %#x\n", s32Ret);
			}
			else if (SendFrmMode == 2)
			{
				s32Ret = MyCover(&GrpINFrm, 320, 180);
				CP_CHECK_PRINT(s32Ret != HI_SUCCESS, "MyCover GrpINFrm fail %#x\n", s32Ret);
				s32Ret = HI_MPI_VO_SendFrame(0, 0, &GrpINFrm, 1000);
				CP_CHECK_PRINT(s32Ret != HI_SUCCESS, "HI_MPI_VO_SendFrame GrpINFrm fail %#x\n", s32Ret);
			}
			s32Ret = HI_MPI_VPSS_ReleaseGrpFrame(0, 0, &GrpINFrm);
			CP_CHECK_PRINT(HI_SUCCESS != s32Ret, "HI_MPI_VPSS_ReleaseGrpFrame GrpINFrm:0x%x\n", s32Ret);
			s32Ret = HI_MPI_VPSS_ReleaseChnFrame(0, 1, &stExtFrmInfo);
			CP_CHECK_PRINT(HI_SUCCESS != s32Ret, "HI_MPI_VPSS_ReleaseChnFrame stExtFrmInfo:0x%x\n", s32Ret);
			Forward_Finsh = HI_FALSE;
			gettimeofday(&total_time_stop, NULL);
			printf("\DATA DEAL total time :%d\n\n", total_time_stop.tv_usec - total_time_start.tv_usec + 1000000 * (total_time_stop.tv_sec - total_time_start.tv_sec));
		}
		usleep(1000);
	}
	HI_MPI_SYS_MmzFree(TempImg.au64PhyAddr[0], (void*)TempImg.au64VirAddr[0]);
}