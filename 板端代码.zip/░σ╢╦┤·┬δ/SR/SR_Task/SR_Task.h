#pragma once
#include <sys/prctl.h>
#include "mpi_nnie.h"
#include "deal_img.h"
void* SR_NNIE_FILL_Forward(void* pArgs);
void* SR_NNIE_DEAL_DATA(void* pArgs);

extern volatile HI_BOOL SR_Task_Finsh;
extern volatile HI_BOOL Forward_Finsh;
extern volatile HI_BOOL Write_bool;
extern volatile uint8_t  SendFrmMode;


