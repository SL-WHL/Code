#include "SR_nnie.h"

#ifdef __HuaweiLite__
int app_main(int argc, char* argv[])
#else
int main(int argc, char* argv[])
#endif
{
	int32_t  s32Ret = SR_main();
	return s32Ret;
}







