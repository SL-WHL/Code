﻿/*
 * Copyright (c) 2021 HiSilicon (Shanghai) Technologies CO., LIMITED.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef IVE_HELP_H
#define IVE_HELP_H

#include <stdbool.h>
#include <stdint.h>

#include "hi_common.h"
#include "hi_comm_ive.h"
#include "hi_comm_video.h"
#include "hi_comm_venc.h"
#include "hi_ive.h"
#include "mpi_ive.h"

#define HI_CHK_RET(ret, format, ...) do { \
    if ((ret) != 0) { \
        printf(format, ##__VA_ARGS__); \
        return ret; \
    } \
}   while (0)

#define HI_CHK_GOTO(ret, label, format, ...) do { \
    if ((ret) != 0) { \
        printf(format, ##__VA_ARGS__); \
        goto label; \
    } \
}   while (0)
typedef struct RectBox {
    int xmin;
    int ymin;
    int xmax;
    int ymax;
}   RectBox;
#ifdef __cplusplus
extern "C" {
#endif
    void MppFrmSetBuf(VIDEO_FRAME_INFO_S* frm,
        const VB_CAL_CONFIG_S* vbCfg, HI_U64 phyAddr, uint8_t* virAddr);
    void MppFrmDestroy(VIDEO_FRAME_INFO_S* frm);

    /**
        销毁ive Image.
    */
    void IveImgDestroy(IVE_IMAGE_S* img);

    /**
        缩放ive image.

        支持任意倍数的缩放.
        此函数会为dst分配空间来存储缩放后的图像.
        user负责调用IveImgDestroy()销毁@param dst返回的image.

        @param src[in]: 待缩放的原始image.
        @param dst[out]: 保存缩放后的image.
        @param dstWidth[in]: 需要的缩放width.
        @param dstHeight[in]: 需要的缩放height.
    */
    int IveImgResize(
        const IVE_IMAGE_S* src, IVE_IMAGE_S* dst,
        uint32_t dstWidth, uint32_t dstHeight);

    /**
        ive image RGB to BGR.
    */
    int ImgRgbToBgr(IVE_IMAGE_S* img);

    /**
        ive image RGB to YUV.
    */
    int ImgRgbToYuv(IVE_IMAGE_S* src, IVE_IMAGE_S* dst, IVE_IMAGE_TYPE_E dstType);



    /**
        YUV video frame to RGB ive image.
    */
    int FrmToRgbImg(VIDEO_FRAME_INFO_S* frm, IVE_DST_IMAGE_S* img);

    /**
        video YUV frame to ive image (U8C1).
    */
    int FrmToU8c1Img(const VIDEO_FRAME_INFO_S* frm, IVE_IMAGE_S* img);

    /**
        video frame to ive image.
        复制数据指针，不复制数据。
    */
    int FrmToOrigImg(const VIDEO_FRAME_INFO_S* frm, IVE_IMAGE_S* img);

    /**
        ive image to video frame .
        复制数据指针，不复制数据。
    */
    int OrigImgToFrm(const IVE_IMAGE_S* img, VIDEO_FRAME_INFO_S* frm);

    int ImgYuvCrop(const IVE_IMAGE_S* src, IVE_IMAGE_S* dst, const RectBox* origBox);

    int IveWriteFile(IVE_IMAGE_S* pstImg, FILE* pFp);
    int MppFrmCreate(
        VIDEO_FRAME_INFO_S* frm,
        int width, int height,
        PIXEL_FORMAT_E pixelFormat,
        DATA_BITWIDTH_E bitWidth,
        COMPRESS_MODE_E compressMode,
        int align);

#ifdef __cplusplus
}
#endif

#endif // IVE_HELP_H
