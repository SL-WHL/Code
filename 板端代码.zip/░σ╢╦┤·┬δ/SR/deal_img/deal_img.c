﻿
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdbool.h>

#include "hi_comm_vb.h"
#include "hi_comm_vgs.h"
#include "hi_comm_region.h"
#include "mpi_sys.h"
#include "mpi_vgs.h"
#include "sample_comm.h"

#include "deal_img.h"

#define HI_OVEN_BASE        2 
#define HI_INT32_BITS       32

#define IMG_FULL_CHN    3 // 全通道/三通道, for YUV444, RGB888
#define IMG_HALF_CHN    2 // 半通道，for YUV420/422
#define THREE_TIMES     3
#define TWO_TIMES       2




#define HI_ALIGN2(num) (((num) + 2 - 1) / 2 * 2)
#define HI_ALIGN8(num) (((num) + 8 - 1) / 8 * 8)
#define HI_ALIGN16(num) (((num) + 16 - 1) / 16 * 16)
#define HI_ALIGN32(num) (((num) + 32 - 1) / 32 * 32)


typedef enum AlignType {
    ALIGN_TYPE_2 = 2, // 按2byte对齐
    ALIGN_TYPE_16 = 16, // 按16byte对齐
    ALIGN_TYPE_32 = 32, // 按32byte对齐
}   AlignType;

static uint32_t IveCalStride(IVE_IMAGE_TYPE_E enType, uint32_t width, AlignType align)
{
    uint32_t size = 1;

    switch (enType) {
    case IVE_IMAGE_TYPE_U8C1:
    case IVE_IMAGE_TYPE_S8C1:
    case IVE_IMAGE_TYPE_S8C2_PACKAGE:
    case IVE_IMAGE_TYPE_S8C2_PLANAR:
    case IVE_IMAGE_TYPE_U8C3_PACKAGE:
    case IVE_IMAGE_TYPE_U8C3_PLANAR:
        size = sizeof(HI_U8);
        break;
    case IVE_IMAGE_TYPE_S16C1:
    case IVE_IMAGE_TYPE_U16C1:
        size = sizeof(HI_U16);
        break;
    case IVE_IMAGE_TYPE_S32C1:
    case IVE_IMAGE_TYPE_U32C1:
        size = sizeof(uint32_t);
        break;
    case IVE_IMAGE_TYPE_S64C1:
    case IVE_IMAGE_TYPE_U64C1:
        size = sizeof(uint64_t);
        break;
    default:
        break;
    }

    if (align == ALIGN_TYPE_16) {
        return HI_ALIGN16(width * size);
    }
    else if (align == ALIGN_TYPE_32) {
        return HI_ALIGN32(width * size);
    }
    else {
        HI_ASSERT(0);
        return 0;
    }
}
int IntZoomTo(int n, double rate, double rateMin, double rateMax)
{
    HI_ASSERT(rateMin < 1 && rateMax > 1);
    int ret;

    if (!rateMin) {
        HI_ASSERT(rateMin);
        return n;
    }
    else {
        if (rate > rateMax) {
            ret = n * (int)rateMax;
        }
        else if (rate < rateMin) {
            ret = n / (int)(1 / rateMin);
        }
        else {
            ret = (int)(n * rate);
        }
        return ret < 1 ? 1 : ret;
    }
}

void MppFrmSetBuf(VIDEO_FRAME_INFO_S* frm,
    const VB_CAL_CONFIG_S* vbCfg, HI_U64 phyAddr, uint8_t* virAddr)
{
    // 目前只支持SP422/SP420，不支持SP444，没有使用addr[2]
    frm->stVFrame.u32HeaderStride[0] = vbCfg->u32HeadStride;
    frm->stVFrame.u32HeaderStride[1] = vbCfg->u32HeadStride;
    frm->stVFrame.u32HeaderStride[2] = vbCfg->u32HeadStride; // 2: 数组下标,不越界
    frm->stVFrame.u64HeaderPhyAddr[0] = phyAddr;
    frm->stVFrame.u64HeaderPhyAddr[1] = frm->stVFrame.u64HeaderPhyAddr[0] + vbCfg->u32HeadYSize;
    frm->stVFrame.u64HeaderPhyAddr[2] = frm->stVFrame.u64HeaderPhyAddr[1]; // 2: 数组下标,不越界
    frm->stVFrame.u64HeaderVirAddr[0] = (HI_U64)(HI_UL)virAddr;
    frm->stVFrame.u64HeaderVirAddr[1] = frm->stVFrame.u64HeaderVirAddr[0] + vbCfg->u32HeadYSize;
    frm->stVFrame.u64HeaderVirAddr[2] = frm->stVFrame.u64HeaderVirAddr[1]; // 2: 数组下标,不越界

    frm->stVFrame.u32Stride[0] = vbCfg->u32MainStride;
    frm->stVFrame.u32Stride[1] = vbCfg->u32MainStride;
    frm->stVFrame.u32Stride[2] = vbCfg->u32MainStride; // 2: 数组下标,不越界
    frm->stVFrame.u64PhyAddr[0] = frm->stVFrame.u64HeaderPhyAddr[0] + vbCfg->u32HeadSize;
    frm->stVFrame.u64PhyAddr[1] = frm->stVFrame.u64PhyAddr[0] + vbCfg->u32MainYSize;
    frm->stVFrame.u64PhyAddr[2] = frm->stVFrame.u64PhyAddr[1]; // 2: 数组下标,不越界
    frm->stVFrame.u64VirAddr[0] = frm->stVFrame.u64HeaderVirAddr[0] + vbCfg->u32HeadSize;
    frm->stVFrame.u64VirAddr[1] = frm->stVFrame.u64VirAddr[0] + vbCfg->u32MainYSize;
    frm->stVFrame.u64VirAddr[2] = frm->stVFrame.u64VirAddr[1]; // 2: 数组下标,不越界
}



int MppFrmCreate(
    VIDEO_FRAME_INFO_S* frm,
    int width, int height,
    PIXEL_FORMAT_E pixelFormat,
    DATA_BITWIDTH_E bitWidth,
    COMPRESS_MODE_E compressMode,
    int align)
{
    HI_ASSERT(frm);
    VB_CAL_CONFIG_S vbCfg;

    if (memset_s(frm, sizeof(*frm), 0, sizeof(*frm)) != EOK) {
        HI_ASSERT(0);
    }

    HI_ASSERT(width > 0 && height > 0);
    if ((int)pixelFormat < 0) {
        pixelFormat = PIXEL_FORMAT_YVU_SEMIPLANAR_420;
    }
    if ((int)bitWidth < 0) {
        bitWidth = DATA_BITWIDTH_8;
    }
    if ((int)compressMode < 0) {
        compressMode = COMPRESS_MODE_NONE;
    }
    if (align < 0) {
        align = 0;
    }

    COMMON_GetPicBufferConfig(width, height, pixelFormat, bitWidth, compressMode, align, &vbCfg);

    VB_BLK vbHnd = HI_MPI_VB_GetBlock(VB_INVALID_POOLID, vbCfg.u32VBSize, NULL);


    HI_U64 phyAddr = HI_MPI_VB_Handle2PhysAddr(vbHnd);
    HI_ASSERT(phyAddr);
    uint8_t* virAddr = (uint8_t*)HI_MPI_SYS_Mmap(phyAddr, vbCfg.u32VBSize);
    HI_ASSERT(virAddr);

    // u64PrivateData用来存储映射的内存区长度和vbHnd，在destroy时会用到
    frm->stVFrame.u64PrivateData = ((uint64_t)(uint32_t)vbHnd) << HI_INT32_BITS;
    frm->stVFrame.u64PrivateData |= (uint64_t)vbCfg.u32VBSize; // ensure xiao

    frm->enModId = HI_ID_VGS;
    frm->u32PoolId = HI_MPI_VB_Handle2PoolId(vbHnd);

    frm->stVFrame.u32Width = width;
    frm->stVFrame.u32Height = height;
    frm->stVFrame.enField = VIDEO_FIELD_FRAME;
    frm->stVFrame.enPixelFormat = pixelFormat;
    frm->stVFrame.enVideoFormat = VIDEO_FORMAT_LINEAR;
    frm->stVFrame.enCompressMode = compressMode;
    frm->stVFrame.enDynamicRange = DYNAMIC_RANGE_SDR8;
    frm->stVFrame.enColorGamut = COLOR_GAMUT_BT601;

    MppFrmSetBuf(frm, &vbCfg, phyAddr, virAddr);
    return HI_SUCCESS;
}
bool MppFrmValid(const VIDEO_FRAME_INFO_S* frm)
{
    // VPSS输出的frame默认没有映射虚地址
    return frm->stVFrame.u64PhyAddr[0];
}
void MppFrmDestroy(VIDEO_FRAME_INFO_S* frm)
{
    if (!MppFrmValid(frm)) {
        return;
    }

    // u64PrivateData被用来存储映射的内存区长度和vbHnd，在create时设置
    uint32_t memSize = (uint32_t)(frm->stVFrame.u64PrivateData);
    uint32_t vbHnd = (uint32_t)(frm->stVFrame.u64PrivateData >> HI_INT32_BITS);
    HI_S32 ret;

    ret = HI_MPI_SYS_Munmap((void*)(uintptr_t)frm->stVFrame.u64VirAddr[0], memSize);
    HI_ASSERT(ret == HI_SUCCESS);
    ret = HI_MPI_VB_ReleaseBlock(vbHnd);
    HI_ASSERT(ret == HI_SUCCESS);
    if (memset_s(frm, sizeof(*frm), 0, sizeof(*frm)) != EOK) {
        HI_ASSERT(0);
    }
}
/**
    执行一次VGS resize.

    每一次VGS resize的缩放倍数是有限制的. VGS支持对一幅图像进行缩放，最大支持图像
    宽高均放大16倍，缩小30 倍。支持单分量（Y）缩放。
*/
int VgsResizeOnce(
    const VIDEO_FRAME_INFO_S* src,
    VIDEO_FRAME_INFO_S* dst,
    uint32_t dstWidth, uint32_t dstHeight)
{
    HI_ASSERT(src && dst);
    HI_ASSERT(dstWidth > 0 && dstHeight > 0);
    VGS_HANDLE jobHnd = -1;
    VGS_TASK_ATTR_S task;
    int ret;

    ret = MppFrmCreate(dst, dstWidth, dstHeight,
        src->stVFrame.enPixelFormat, DATA_BITWIDTH_8,
        src->stVFrame.enCompressMode, 0);
    HI_CHK_RET(ret, "frm resize FAIL, for create dstFrm FAIL\n");

    if (memset_s(&task, sizeof(task), 0, sizeof(task)) != EOK) {
        HI_ASSERT(0);
    }
    task.stImgIn = *src;
    task.stImgOut = *dst;

    ret = HI_MPI_VGS_BeginJob(&jobHnd);
    HI_CHK_GOTO(ret, FAIL, "HI_MPI_VGS_BeginJob FAIL, ret=%08X\n", ret);
    HI_ASSERT(jobHnd >= 0);

    ret = HI_MPI_VGS_AddScaleTask(jobHnd, &task, VGS_SCLCOEF_NORMAL);
    HI_CHK_GOTO(ret, FAIL, "HI_MPI_VGS_AddScaleTask FAIL, ret=%08X\n", ret);

    ret = HI_MPI_VGS_EndJob(jobHnd);
    HI_CHK_GOTO(ret, FAIL, "HI_MPI_VGS_EndJob FAIL, ret=%08X\n", ret);
    return 0;

FAIL:
    if (jobHnd >= 0 && HI_MPI_VGS_CancelJob(jobHnd) != HI_SUCCESS) {
        HI_ASSERT(0);
    }
    MppFrmDestroy(dst);
    return ret;
}
//
//
///**
//    resize frame.
//
//    多次调用vgs_resize以实现任意比例的缩放。
//    为简化实现，约定每次缩放最大14倍，此时宽、高仅需2像素对齐。
//
//    当两个方向缩放方向不同时，例如一向(如X)放大，另一向缩小倍，无需特别处理。
//    此时某个方向或两个方向缩放比例均超标，也不需要特别处理。
//*/
int MppFrmResize(
    const VIDEO_FRAME_INFO_S* src,
    VIDEO_FRAME_INFO_S* dst,
    uint32_t dstWidth, uint32_t dstHeight)
{
    static const double rateMax = 14.0; // 放大的最大倍数
    static const double rateMin = 1.0 / rateMax; // 放大的最小倍数，也即缩小的最大q比例

    uint32_t srcWidth = src->stVFrame.u32Width;
    uint32_t srcHeight = src->stVFrame.u32Height;
    //HI_ASSERT(srcWidth > 0 && srcHeight > 0);
    //HI_ASSERT(!(srcWidth % HI_OVEN_BASE) && !(srcHeight % HI_OVEN_BASE));
    //HI_ASSERT(dstWidth > 0 && dstHeight > 0);
    //HI_ASSERT(!(dstWidth % HI_OVEN_BASE) && !(dstHeight % HI_OVEN_BASE));
    int ret;

    // 放大倍数
    double widthRate = ((double)dstWidth) / (double)srcWidth; // >1表示放大，<1表示缩小
    double heightRate = ((double)dstHeight) / (double)srcHeight; // >1表示放大，<1表示缩小

    // 根据缩放倍数分别处理
    if (widthRate > rateMax || widthRate < rateMin ||
        heightRate > rateMax || heightRate < rateMin) {
        // 缩放倍数超过一次VGS的最大值时，递归处理 ...
        uint32_t midWidth = (uint32_t)IntZoomTo((int)srcWidth, widthRate, rateMin, rateMax);
        uint32_t midHeight = (uint32_t)IntZoomTo((int)srcHeight, heightRate, rateMin, rateMax);
        // 确保为偶数。为奇数时，放大则减一，否则加一
        if (midWidth % HI_OVEN_BASE) {
            midWidth += widthRate > 1 ? -1 : 1;
        }
        if (midHeight % HI_OVEN_BASE) {
            midHeight += heightRate > 1 ? -1 : 1;
        }

        printf("@@@ multi-lev vgs resize, src={%u, %u}, mid={%u, %u}, dst={%u, %u}, rate={%.4f, %.4f}\n",
            srcWidth, srcHeight, midWidth, midHeight, dstWidth, dstHeight, widthRate, heightRate);

        // 缩放一次
        VIDEO_FRAME_INFO_S midFrm;
        ret = VgsResizeOnce(src, &midFrm, midWidth, midHeight);

        // 以midFrm为src递归调用
        ret = MppFrmResize(&midFrm, dst, dstWidth, dstHeight);
        MppFrmDestroy(&midFrm);

    }
    else { // 缩放倍数未超过一次VGS的最大值，直接完成
        ret = VgsResizeOnce(src, dst, dstWidth, dstHeight);
        //HI_CHK_RET(ret, "VgsResizeOnce(dw=%u, dh=%u) FAIL\n", dstWidth, dstHeight);
    }
    return ret;
}

    /**
    释放为ive resize ctrl等分配的内存.
*/
static void IveCtrlFree(IVE_MEM_INFO_S* memInfo)
{
    if (HI_MPI_SYS_MmzFree(memInfo->u64PhyAddr, (void*)((uintptr_t)memInfo->u64VirAddr)) < 0) {
        HI_ASSERT(0);
    }

    memInfo->u64PhyAddr = 0;
    memInfo->u64VirAddr = 0;
}

int FrmToRgbImg(VIDEO_FRAME_INFO_S* srcFrm, IVE_DST_IMAGE_S* dstImg)
{
    HI_ASSERT(srcFrm && dstImg);
    const static int chnNum = 3;
    IVE_HANDLE iveHnd;
    IVE_SRC_IMAGE_S srcImg;
    HI_BOOL finish;
    int ret;

    if (memset_s(&srcImg, sizeof(srcImg), 0, sizeof(srcImg)) != EOK) {
        HI_ASSERT(0);
    }
    srcImg.u32Width = srcFrm->stVFrame.u32Width;
    srcImg.u32Height = srcFrm->stVFrame.u32Height;

    PIXEL_FORMAT_E enPixelFormat = srcFrm->stVFrame.enPixelFormat;
    if (enPixelFormat == PIXEL_FORMAT_YVU_SEMIPLANAR_420) {
        srcImg.enType = IVE_IMAGE_TYPE_YUV420SP;
    }
    else if (enPixelFormat == PIXEL_FORMAT_YVU_SEMIPLANAR_422) {
        srcImg.enType = IVE_IMAGE_TYPE_YUV422SP;
    }
    else {
        HI_ASSERT(0);
        return -1;
    }

    // 分别复制3个通道的地址
    for (int i = 0; i < chnNum; i++) {
        srcImg.au64PhyAddr[i] = srcFrm->stVFrame.u64PhyAddr[i];
        srcImg.au64VirAddr[i] = srcFrm->stVFrame.u64VirAddr[i];
        srcImg.au32Stride[i] = srcFrm->stVFrame.u32Stride[i];
    }

    ret = IveImgCreate(dstImg, IVE_IMAGE_TYPE_U8C3_PLANAR, srcImg.u32Width, srcImg.u32Height);
    if (ret)
    {
        printf("IveImgCreate fail\n");
        return ret;
    }

    IVE_CSC_CTRL_S stCSCCtrl = { IVE_CSC_MODE_PIC_BT601_YUV2RGB };
    ret = HI_MPI_IVE_CSC(&iveHnd, &srcImg, dstImg, &stCSCCtrl, HI_TRUE);
    if (ret)
    {
        printf("CSC fail__        \n");
        goto FAIL;
    }

    ret = HI_MPI_IVE_Query(iveHnd, &finish, HI_TRUE);
    if (ret)
    {
        printf("Query fail__\n");
        goto FAIL;
    }
    return ret;

FAIL:
    IveImgDestroy(dstImg);
    return ret;
}

int IveImgCreate(IVE_IMAGE_S* img,
    IVE_IMAGE_TYPE_E enType, uint32_t width, uint32_t height)
{
    HI_ASSERT(img);
    uint32_t oneChnSize;
    uint32_t size;
    int ret;

    if (memset_s(img, sizeof(*img), 0, sizeof(*img)) != EOK) {
        HI_ASSERT(0);
    }
    img->enType = enType;
    img->u32Width = width;
    img->u32Height = height;
    img->au32Stride[0] = IveCalStride(img->enType, img->u32Width, ALIGN_TYPE_16);

    switch (enType) {
    case IVE_IMAGE_TYPE_U8C1:
    case IVE_IMAGE_TYPE_S8C1: // 只有1个通道
        size = img->au32Stride[0] * img->u32Height;
        ret = HI_MPI_SYS_MmzAlloc(&img->au64PhyAddr[0], (void**)&img->au64VirAddr[0], NULL, NULL, size);
        HI_CHK_RET(ret, "Mmz Alloc FAIL, err=%#x\n", ret);
        break;

    case IVE_IMAGE_TYPE_YUV420SP: // size相当于像素的1.5倍(3/2)，相当于2通道
    case IVE_IMAGE_TYPE_YUV422SP: // size相当于像素的2倍，相当于2通道
        if (enType == IVE_IMAGE_TYPE_YUV420SP) {
            size = img->au32Stride[0] * img->u32Height * THREE_TIMES / TWO_TIMES;
        }
        else {
            size = img->au32Stride[0] * img->u32Height * TWO_TIMES;
        }
        ret = HI_MPI_SYS_MmzAlloc(&img->au64PhyAddr[0], (void**)&img->au64VirAddr[0], NULL, NULL, size);
        HI_CHK_RET(ret, "Mmz Alloc FAIL, ret=%#x\n", ret);

        // 设置通道1的地址的stride，二者都需要通道1
        img->au32Stride[1] = img->au32Stride[0];
        img->au64PhyAddr[1] = img->au64PhyAddr[0] + img->au32Stride[0] * (uint64_t)img->u32Height;
        img->au64VirAddr[1] = img->au64VirAddr[0] + img->au32Stride[0] * (uint64_t)img->u32Height;
        break;

    case IVE_IMAGE_TYPE_U8C3_PLANAR: // 3通道,常用于RGB
        oneChnSize = img->au32Stride[0] * img->u32Height;
        size = oneChnSize * 3; // 3个通道size相同
        ret = HI_MPI_SYS_MmzAlloc(&img->au64PhyAddr[0], (void**)&img->au64VirAddr[0], NULL, NULL, size);
        HI_CHK_RET(ret, "Mmz Alloc FAIL, ret=%#x\n", ret);

        // 设置通道1，通道2的地址与stride
        img->au64VirAddr[1] = img->au64VirAddr[0] + oneChnSize;
        img->au64PhyAddr[1] = img->au64PhyAddr[0] + oneChnSize;
        img->au32Stride[1] = img->au32Stride[0];
        img->au64VirAddr[2] = img->au64VirAddr[1] + oneChnSize; // 2: au64VirAddr数组下标,不越界
        img->au64PhyAddr[2] = img->au64PhyAddr[1] + oneChnSize; // 2: au64VirAddr数组下标,不越界
        img->au32Stride[2] = img->au32Stride[0]; // 2: au64VirAddr数组下标,不越界
        break;

        // 暂不支持的type: YVC420P, YUV422P, S8C2_PACKAGE, S8C2_PLANAR,
        // S32C1, U32C1, S64C1, U64C1, S16C1, U16C1, U8C3_PACKAGE,etc.
    default:
        HI_ASSERT(0);
        break;
    }
    return HI_SUCCESS;
}


void IveImgDestroy(IVE_IMAGE_S* img)
{
    for (int i = 0; i < 3; i++) {
        if (img->au64PhyAddr[0] && img->au64VirAddr[0]) {
            HI_MPI_SYS_MmzFree(img->au64PhyAddr[i], (void*)((uintptr_t)img->au64VirAddr[i]));
            img->au64PhyAddr[i] = 0;
            img->au64VirAddr[i] = 0;
        }
    }
    if (memset_s(img, sizeof(*img), 0, sizeof(*img)) != EOK) {
        HI_ASSERT(0);
    }
}

int ImgRgbToBgr(IVE_IMAGE_S* img)
{
    uint8_t* rp = NULL;
    uint8_t* bp = NULL;
    uint8_t c;
    int i, j;

    // 用IVE DMA替代，以提升性能
    HI_ASSERT(img->enType == IVE_IMAGE_TYPE_U8C3_PLANAR);
    HI_ASSERT(img->au32Stride[0] >= img->u32Width);
    HI_ASSERT(img->au32Stride[1] >= img->u32Width);
    HI_ASSERT(img->au32Stride[2] >= img->u32Width); // 2: au32Stride数组下标,不越界

    rp = (uint8_t*)(uintptr_t)img->au64VirAddr[0];
    bp = (uint8_t*)(uintptr_t)img->au64VirAddr[2]; // 2: VirAddr数组下标,不越界
    HI_ASSERT(rp && bp);
    for (i = 0; i < img->u32Height; i++) {
        for (j = 0; j < img->u32Width; j++) {
            c = rp[j];
            rp[j] = bp[j];
            bp[j] = c;
        }
        rp += img->au32Stride[0];
        bp += img->au32Stride[2]; // 2: au32Stride数组下标,不越界
    }
    return 0;
}

/**
    ive image RGB to YUV.
*/
int ImgRgbToYuv(IVE_IMAGE_S* src, IVE_IMAGE_S* dst, IVE_IMAGE_TYPE_E dstType)
{
    IVE_HANDLE iveHnd;
    HI_BOOL finish;
    HI_S32 ret;

    if (memset_s(dst, sizeof(*dst), 0, sizeof(*dst)) != EOK) {
        HI_ASSERT(0);
    }

    ret = IveImgCreate(dst, dstType, src->u32Width, src->u32Height);
    HI_CHK_RET(ret, "IveImgCreate FAIL, ret=%#x\n", ret);

    IVE_CSC_CTRL_S stCSCCtrl = { IVE_CSC_MODE_VIDEO_BT601_RGB2YUV };
    ret = HI_MPI_IVE_CSC(&iveHnd, src, dst, &stCSCCtrl, HI_TRUE);
    HI_CHK_RET(ret, "HI_MPI_IVE_CSC FAIL, ret=%#x\n", ret);

    ret = HI_MPI_IVE_Query(iveHnd, &finish, HI_TRUE);
    HI_CHK_RET(ret, "HI_MPI_IVE_Query FAIL, ret=%#x\n", ret);
    return ret;
}
/**
    video frame to ive image.
    复制数据指针，不复制数据。
*/
int FrmToOrigImg(const VIDEO_FRAME_INFO_S* frm, IVE_IMAGE_S* img)
{
    static const int chnNum = 2; // 目前只支持YUV420/422，因此只复制2个通道的地址
    PIXEL_FORMAT_E pixelFormat = frm->stVFrame.enPixelFormat;

    if (memset_s(img, sizeof(*img), 0, sizeof(*img)) != EOK) {
        HI_ASSERT(0);
    }

    img->u32Width = frm->stVFrame.u32Width;
    img->u32Height = frm->stVFrame.u32Height;

    if (pixelFormat == PIXEL_FORMAT_YVU_SEMIPLANAR_420) {
        img->enType = IVE_IMAGE_TYPE_YUV420SP;
    }
    else if (pixelFormat == PIXEL_FORMAT_YVU_SEMIPLANAR_422) {
        img->enType = IVE_IMAGE_TYPE_YUV422SP;
    }
    else {
        HI_ASSERT(0);
        return -1;
    }

    for (int i = 0; i < chnNum; i++) {
        img->au64PhyAddr[i] = frm->stVFrame.u64PhyAddr[i];
        img->au64VirAddr[i] = frm->stVFrame.u64VirAddr[i];
        img->au32Stride[i] = frm->stVFrame.u32Stride[i];
    }
    return 0;
}


int OrigImgToFrm(const IVE_IMAGE_S* img, VIDEO_FRAME_INFO_S* frm)
{
    static const int chnNum = 3;
    IVE_IMAGE_TYPE_E enType = img->enType;
    if (memset_s(frm, sizeof(*frm), 0, sizeof(*frm)) != EOK) {
        HI_ASSERT(0);
    }

    frm->stVFrame.u32Width = img->u32Width;
    frm->stVFrame.u32Height = img->u32Height;

    if (enType == IVE_IMAGE_TYPE_YUV420SP) {
        frm->stVFrame.enPixelFormat = PIXEL_FORMAT_YVU_SEMIPLANAR_420;
    }
    else if (enType == IVE_IMAGE_TYPE_YUV422SP) {
        frm->stVFrame.enPixelFormat = PIXEL_FORMAT_YVU_SEMIPLANAR_422;
    }
    else {
        HI_ASSERT(0);
        return -1;
    }

    for (int i = 0; i < chnNum; i++) {
        frm->stVFrame.u64PhyAddr[i] = img->au64PhyAddr[i];
        frm->stVFrame.u64VirAddr[i] = img->au64VirAddr[i];
        frm->stVFrame.u32Stride[i] = img->au32Stride[i];
    }
    return 0;
}



int ImgYuvCrop(const IVE_IMAGE_S* src, IVE_IMAGE_S* dst, const RectBox* origBox)
{
    RectBox box = *origBox;
    int boxWidth = box.xmax - box.xmin;
    int boxHeight = box.ymax - box.ymin;
    int ret;

    HI_ASSERT(boxWidth > 0 && boxWidth <= src->u32Width);
    HI_ASSERT(boxHeight > 0 && boxHeight <= src->u32Height);
    HI_ASSERT(src->au64VirAddr[0]);
    HI_ASSERT(src->au32Stride[0] >= src->u32Width);

    // box的width/height调整为2的倍数
    if (boxWidth == 1 || boxHeight == 1) {
        printf("box dstWidth=1 && dstHeight=1\n");
        return -1;
    }
    if (boxWidth % HI_OVEN_BASE) {
        box.xmax--;
        boxWidth--;
    }
    if (boxHeight % HI_OVEN_BASE) {
        box.ymax--;
        boxHeight--;
    }
    // 创建空的dst img
    printf("IveImgCreate begin:%d\n",src->enType);
    ret = IveImgCreate  (dst, src->enType, boxWidth, boxHeight);
    printf("IveImgCreate END:%d\n",ret);
    HI_ASSERT(!ret);
    // 用IVE DMA来复制，以提升性能
    // copy box from src to dst
    // Y
    int srcStrideY = src->au32Stride[0];
    int dstStrideY = dst->au32Stride[0];
    uint8_t* srcBufY = (uint8_t*)((uintptr_t)src->au64VirAddr[0]);
    uint8_t* dstBufY = (uint8_t*)((uintptr_t)dst->au64VirAddr[0]);
    uint8_t* srcPtrY = &srcBufY[box.ymin * srcStrideY];
    uint8_t* dstPtrY = dstBufY;
    for (int h = 0; h < boxHeight; h++, srcPtrY += srcStrideY, dstPtrY += dstStrideY) {
        if (memcpy_s(dstPtrY, boxWidth, srcPtrY + box.xmin, boxWidth) != EOK) {
            HI_ASSERT(0);
        }
    }
    HI_ASSERT(dstPtrY - dstBufY == boxHeight * dstStrideY);

    // UV
    int srcStrideUV = src->au32Stride[1];
    int dstStrideUV = dst->au32Stride[1];
    uint8_t* srcBufUV = (uint8_t*)((uintptr_t)src->au64VirAddr[1]);
    uint8_t* dstBufUV = (uint8_t*)((uintptr_t)dst->au64VirAddr[1]);
    uint8_t* srcPtrUV = &srcBufUV[(box.ymin / 2) * srcStrideUV];
    uint8_t* dstPtrUV = dstBufUV;
    for (int h = 0; h < (boxHeight / 2); h++, srcPtrUV += srcStrideUV, dstPtrUV += dstStrideUV) {
        if (memcpy_s(dstPtrUV, boxWidth, srcPtrUV + box.xmin, boxWidth) != EOK) {
            HI_ASSERT(0);
        }
    }
    HI_ASSERT(dstPtrUV - dstBufUV == (boxHeight / 2) * dstStrideUV);

    return ret;
}

int IveWriteFile(IVE_IMAGE_S* pstImg, FILE* pFp)
{
    HI_U16 y;
    HI_U8* pU8;
    HI_U16 height;
    HI_U16 width;

    height = pstImg->u32Height;
    width = pstImg->u32Width;
    printf("wgm %s, %d pstImg->enType = %d \r\n", __FUNCTION__, __LINE__, pstImg->enType);
    switch (pstImg->enType)
    {
    case  IVE_IMAGE_TYPE_U8C1:
    case  IVE_IMAGE_TYPE_S8C1:
    {
        pU8 = (HI_U8*)(HI_UL)pstImg->au64VirAddr[0];
        for (y = 0; y < height; y++)
        {
            if (1 != fwrite(pU8, width, 1, pFp))
            {
                printf("Write file fail\n");
                return -1;
            }

            pU8 += pstImg->au32Stride[0];
        }
    }
    break;
    case  IVE_IMAGE_TYPE_YUV420SP:
    {
        pU8 = (HI_U8*)(HI_UL)pstImg->au64VirAddr[0];
        for (y = 0; y < height; y++)
        {
            if (width != fwrite(pU8, 1, width, pFp))
            {
                printf("Write file fail\n");
                return -1;
            }

            pU8 += pstImg->au32Stride[0];
        }

        pU8 = (HI_U8*)(HI_UL)pstImg->au64VirAddr[1];
        for (y = 0; y < height / 2; y++)
        {
            if (width != fwrite(pU8, 1, width, pFp))
            {
                printf("Write file fail\n");
                return -1;
            }

            pU8 += pstImg->au32Stride[1];
        }
    }
    break;
    case IVE_IMAGE_TYPE_YUV422SP:
    {
        pU8 = (HI_U8*)(HI_UL)pstImg->au64VirAddr[0];
        for (y = 0; y < height; y++)
        {
            if (width != fwrite(pU8, 1, width, pFp))
            {
                printf("Write file fail\n");
                return -1;
            }

            pU8 += pstImg->au32Stride[0];
        }

        pU8 = (HI_U8*)(HI_UL)pstImg->au64VirAddr[1];
        for (y = 0; y < height; y++)
        {
            if (width != fwrite(pU8, 1, width, pFp))
            {
                printf("Write file fail\n");
                return -1;
            }

            pU8 += pstImg->au32Stride[1];
        }
    }
    break;
    case IVE_IMAGE_TYPE_S16C1:
    case  IVE_IMAGE_TYPE_U16C1:
    {
        pU8 = (HI_U8*)(HI_UL)pstImg->au64VirAddr[0];
        for (y = 0; y < height; y++)
        {
            if (sizeof(HI_U16) != fwrite(pU8, width, sizeof(HI_U16), pFp))
            {
                printf("Write file fail\n");
                return -1;
            }

            pU8 += pstImg->au32Stride[0] * 2;
        }
    }
    break;
    case IVE_IMAGE_TYPE_U32C1:
    {

        pU8 = (HI_U8*)(HI_UL)pstImg->au64VirAddr[0];
        for (y = 0; y < height; y++)
        {
            if (width != fwrite(pU8, sizeof(HI_U32), width, pFp))
            {
                printf("Write file fail\n");
                return -1;
            }

            pU8 += pstImg->au32Stride[0] * 4;
        }
        break;
    }

    default:
        break;
    }

    return 0;
}

