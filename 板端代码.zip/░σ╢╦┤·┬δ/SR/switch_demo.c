#include <poll.h>
#include <stdio.h>
#include <stdint.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/fcntl.h>
#include "hi_type.h"
#define MSG(args...) printf(args)

/* 
	function: GPIO enable 
	pin: gpio number
*/
static int gpio_export(int pin)  
{  
    char buffer[64] = {0};  
    int len = -1;  
    int fd = -1;  

    fd = open("/sys/class/gpio/export", O_WRONLY);  
    if (fd < 0) 
	{ 
        MSG("Failed to open export for writing!\n");  
		close(fd);
        return(-1);  
    }  
	
    len = snprintf(buffer, sizeof(buffer), "%d", pin);  
    if (write(fd, buffer, len) < 0)
	{  
        MSG("Failed to export gpio!");  
		close(fd);
        return -1;  
    } 
	
    close(fd);  
    return 0; 
}  

/* 
	function: GPIO disable
	pin: gpio number
*/
static int gpio_unexport(int pin)  
{  
    char buffer[64] = {0};  
    int len = -1;  
    int fd = -1;   

    fd = open("/sys/class/gpio/unexport", O_WRONLY);  
    if (fd < 0) 
	{  
        MSG("Failed to open unexport for writing!\n");  
		close(fd);
        return -1;  
    }  

    len = snprintf(buffer, sizeof(buffer), "%d", pin);  
    if (write(fd, buffer, len) < 0) 
	{  
        MSG("Failed to unexport gpio!");  
		close(fd);
        return -1;  
    }  

    close(fd);  
    return 0;  
} 

/* 
	function: set gpio direction
	pin: gpio number
	dir: 0-->IN, 1-->OUT
*/
static int gpio_direction(int pin, int dir)  
{
    static const char dir_str[] = "in\0out";  
    char path[64] = {0};  
    int fd = -1;  
  
    snprintf(path, sizeof(path), "/sys/class/gpio/gpio%d/direction", pin);  
    fd = open(path, O_WRONLY);  
    if (fd < 0)
	{  
        MSG("Failed to open gpio direction for writing!\n");  
		close(fd);
        return -1;  
    }  

    if (write(fd, &dir_str[dir == 0 ? 0 : 3], dir == 0 ? 2 : 3) < 0)
	{  
        MSG("Failed to set direction!\n");  
		close(fd);
        return -1;  
    }  
	
    close(fd);  
    return 0;  
}  

/* 
	function: set gpio value
	pin: gpio number
	dir: 0-->LOW, 1-->HIGH
*/
static int gpio_write(int pin, int value)  
{  
    static const char values_str[] = "01";  
    char path[64] = {0};  
    int fd = -1;  

    snprintf(path, sizeof(path), "/sys/class/gpio/gpio%d/value", pin);  
    fd = open(path, O_WRONLY);  
    if (fd < 0)
	{  
        MSG("Failed to open gpio value for writing!\n");  
		close(fd);
        return -1;  
    }  

    if (write(fd, &values_str[value == 0 ? 0 : 1], 1) < 0)
	{  
        MSG("Failed to write value!\n");  
		close(fd);
        return -1;  
    } 
	
    close(fd);  
    return 0;  
}

/* 
	function: get gpio value
	pin: gpio number
	dir: 0-->LOW, 1-->HIGH
*/
static int gpio_read(int pin)  
{  
    char path[64] = {0};  
    char value_str[3] = {0};  
    int fd = -1;  

    snprintf(path, sizeof(path), "/sys/class/gpio/gpio%d/value", pin);  
    fd = open(path, O_RDONLY);  
    if (fd < 0) 
	{  
        MSG("Failed to open gpio value for reading!\n");  
		close(fd); 
        return -1;  
    }  

    if (read(fd, value_str, 3) < 0) 
	{  
        MSG("Failed to read value!\n");  
		close(fd); 
        return -1;  
    }  

    close(fd);  
    return (atoi(value_str));
}  

// none表示引脚为输入，不是中断引脚
// rising表示引脚为中断输入，上升沿触发
// falling表示引脚为中断输入，下降沿触发
// both表示引脚为中断输入，边沿触发
// 0-->none, 1-->rising, 2-->falling, 3-->both
static int gpio_edge(int pin, int edge)
{
	const char dir_str[] = "none\0rising\0falling\0both"; 
	char ptr;
	char path[64] = {0};  
	int fd = -1; 

	switch(edge)
	{
		case 0:
			ptr = 0;
			break;
		case 1:
			ptr = 5;
			break;
		case 2:
			ptr = 12;
			break;
		case 3:
			ptr = 20;
			break;
		default:
			ptr = 0;
	} 
	snprintf(path, sizeof(path), "/sys/class/gpio/gpio%d/edge", pin);  
	
	fd = open(path, O_WRONLY);  
	if (fd < 0) 
	{  
		MSG("Failed to open gpio edge for writing!\n");  
		close(fd); 
		return -1;  
	}  

	if (write(fd, &dir_str[ptr], strlen(&dir_str[ptr])) < 0) 
	{  
		MSG("Failed to set edge!\n");  
		close(fd); 
		return -1;  
	}  

	close(fd);  
	return 0;  
}

/* Initialization key 1*/
void init_gpio1(void)
{
	MSG("\n =============== init_gpio1 start ========== \n");
	gpio_unexport(1);
	gpio_export(1);
	gpio_direction(1, 0);
	gpio_edge(1, 2);
	MSG("\n =============== init_gpio1 end ========== \n");
}

/* Initialization key 2*/
void init_gpio2(void)
{
	MSG("\n =============== init_gpio2 start ========== \n");
	gpio_unexport(2);
	gpio_export(2);
	gpio_direction(2, 0);
	gpio_edge(2, 2);
	MSG("\n =============== init_gpio2 end ========== \n");
}
extern volatile uint8_t SendFrmMode;
extern volatile HI_BOOL SR_Task_Finsh;
void *Switch_Thread(void* pArgs)
{
	int gpio1_fd = -1;
	int gpio2_fd = -1;
	int ret1 	 = -1;
	int ret2     = -1;
	char buff[10] = {0};
	struct pollfd fds1[1];
	struct pollfd fds2[1];
	
	/* init key1 and key2 */
	init_gpio1();
	init_gpio2();
	
	gpio1_fd = open("/sys/class/gpio/gpio1/value", O_RDONLY);
	if (gpio1_fd < 0)
	{
		MSG("Failed to open gpio1 !\n");
	}
	fds1[0].fd     = gpio1_fd;
	fds1[0].events = POLLPRI;
	
	gpio2_fd = open("/sys/class/gpio/gpio2/value", O_RDONLY);
	if (gpio2_fd < 0)
	{
		MSG("Failed to open gpio1 !\n");
	}
	fds2[0].fd     = gpio2_fd;
	fds2[0].events = POLLPRI;
	
	while(SR_Task_Finsh==HI_FALSE)
	{
		/* read buffer from the gpio1 */
		ret1 = read(gpio1_fd, buff, 10);
		if (ret1 == -1)
		{
			MSG("gpio1 read error\n");
		}
		
		ret1 = poll(fds1, 1, 0);
		if (ret1 == -1)
		{
			MSG("gpio1 poll error\n");
		}
		
		if (fds1[0].revents & POLLPRI) // 按键2被按下
		{
			ret1 = lseek(gpio1_fd, 0, SEEK_SET);
			if (ret1 == -1)
			{
				MSG("gpio1 lseek error\n");
			}
			SendFrmMode = 2;
		}
		
		/* read buffer from the gpio2 */
		ret2 = read(gpio2_fd, buff, 10);
		if (ret2 == -1)
		{
			MSG("gpio2 read error\n");
		}
		
		ret2 = poll(fds2, 1, 0);
		if (ret2 == -1)
		{
			MSG("gpio2 poll error\n");
		}
		
		if (fds2[0].revents & POLLPRI) // 按键1被按下
		{
			ret2 = lseek(gpio2_fd, 0, SEEK_SET);
			if (ret2 == -1)
			{
				MSG("gpio1 lseek error\n");
			}
			SendFrmMode = 0;
		}
		usleep(10000);
	}
	gpio_unexport(1);
	gpio_unexport(2);
	return 0;
}